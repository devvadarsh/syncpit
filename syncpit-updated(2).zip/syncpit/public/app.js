(function(){document.querySelectorAll("[data-split]").forEach(function(el){var t=el.textContent.trim(),m=el.dataset.split,f=document.createDocumentFragment();
if(m==="chars"){t.split("").forEach(function(c,i){var s=document.createElement("span");s.textContent=c;s.style.setProperty("--i",i);f.appendChild(s);});}
else{t.split(" ").forEach(function(w,i){var s=document.createElement("span");s.className="w";s.textContent=w;s.style.setProperty("--i",i);f.appendChild(s);});}
el.textContent="";el.appendChild(f);});
document.querySelectorAll(".splash-credit .w").forEach(function(w){if(/^(Crown|Lab)$/.test(w.textContent))w.classList.add("accent");});})();

(() => {
const $ = id => document.getElementById(id);
const { highlight, detectLanguage } = window.CRHL;
const CROT = window.CROT;
const reduceMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;
const socket = io();
function ident() { return {}; }   // who you are comes from your session cookie, not from the page
let curUser = null;
const otc = new CROT.Client({
  rev: 0,
  send: (rev, op) => socket.emit("op", { id: roomId, rev, op }),
  apply: op => {
    const ta = $("code"), a = CROT.transformIndex(ta.selectionStart, op, false), b = CROT.transformIndex(ta.selectionEnd, op, false), top = ta.scrollTop;
    shadow = CROT.apply(shadow, op); ta.value = shadow; ta.setSelectionRange(a, b); ta.scrollTop = top;
    updateCount(); scheduleHighlight(); schedulePreview(); $("syncState").textContent = isLocked && !isOwner && !can("room_edit_locked") ? "Read-only · copying allowed" : "Live update received";
  }
});
let shadow = "", roomId = null, creating = false, isOwner = false, isLocked = false;
let recoveredKey = false, prevOwnerKey = "", ownerHideTimer = 0, resetArmed = 0;
let maint = { phase: "off", endsAt: 0 }, maintOffset = 0, maintClock = 0, maintPoll = 0, ownerSaved = false, startArmed = 0;
const OWNER_KEYS_STORAGE = "syncpit-owner-keys-v1";
try { if (!localStorage.getItem(OWNER_KEYS_STORAGE) && localStorage.getItem("coderelay-owner-keys-v1")) localStorage.setItem(OWNER_KEYS_STORAGE, localStorage.getItem("coderelay-owner-keys-v1")); } catch {}
const MAX_CODE_LENGTH = 80000;

/* ---------- splash ---------- */
function endSplash() {
  const splash = $("splash");
  if (!splash) return;
  splash.classList.add("leaving");
  document.body.classList.remove("booting");
  document.body.classList.add("ready");
  try { localStorage.setItem("syncpit-splash-seen", "1"); } catch {}
  setTimeout(() => splash.remove(), reduceMotion ? 50 : 1000);
}
const splashQuick = document.documentElement.classList.contains("splash-quick");     // set early by theme.js for returning visitors
window.addEventListener("load", () => setTimeout(endSplash, reduceMotion ? 150 : splashQuick ? 700 : 3700));

/* ---------- button feel: ripple + label swap ---------- */
document.addEventListener("pointerdown", e => {
  const btn = e.target.closest("button");
  if (!btn || btn.disabled || reduceMotion) return;
  const rect = btn.getBoundingClientRect();
  const size = Math.max(rect.width, rect.height) * 2;
  const r = document.createElement("span");
  r.className = "ripple";
  r.style.width = r.style.height = size + "px";
  r.style.left = (e.clientX - rect.left - size / 2) + "px";
  r.style.top = (e.clientY - rect.top - size / 2) + "px";
  btn.appendChild(r);
  r.addEventListener("animationend", () => r.remove());
});
function setLabel(btn, text) {
  const label = btn.querySelector(".label");
  if (!label || label.textContent === text) return;
  if (reduceMotion) { label.textContent = text; return; }
  label.classList.add("swap");
  setTimeout(() => { label.textContent = text; label.classList.remove("swap"); }, 170);
}
function flashLabel(btn, text, ms = 1600) {
  const label = btn.querySelector(".label");
  const original = btn.dataset.label || (btn.dataset.label = label.textContent);
  setLabel(btn, text);
  clearTimeout(btn._flash);
  btn._flash = setTimeout(() => setLabel(btn, original), ms);
}

/* ---------- owner key storage ---------- */
function getOwnerKey(id) {
  try { return JSON.parse(localStorage.getItem(OWNER_KEYS_STORAGE) || "{}")[id] || ""; } catch { return ""; }
}
function saveOwnerKey(id, token) {
  try { const keys = JSON.parse(localStorage.getItem(OWNER_KEYS_STORAGE) || "{}"); keys[id] = token; localStorage.setItem(OWNER_KEYS_STORAGE, JSON.stringify(keys)); } catch {}
}

/* ---------- UI state ---------- */
function applyPermissions() {
  const canLock = isOwner || can("room_lock"), canDelete = isOwner || can("room_delete");       // the owner key, or a rank power; the server checks both
  const readOnly = isLocked && !isOwner && !can("room_edit_locked");
  $("code").readOnly = readOnly || featureIsOff("edit");
  $("language").disabled = readOnly;
  $("lockBtn").classList.toggle("hidden", !(canLock && roomId));
  $("deleteRoom").classList.toggle("hidden", !(canDelete && roomId));
  $("ownerBox").classList.toggle("hidden", !(isOwner && roomId && getOwnerKey(roomId)));
  if (!(isOwner && roomId)) hideOwnerKey();
  setLabel($("lockBtn"), isLocked ? "Unlock editing" : "Lock editing");
  $("lockBtn").dataset.label = isLocked ? "Unlock editing" : "Lock editing";
  $("lockIndicator").classList.toggle("hidden", !readOnly);
  $("editorCard").classList.toggle("is-readonly", readOnly);
  if (readOnly) $("syncState").textContent = "Read-only · copying allowed";
}
function setStatus(text, connected) {
  $("status").textContent = text;
  $("statusDot").classList.toggle("off", !connected);
}
function showNotice(text, type = "") {
  const n = $("notice");
  n.className = "notice" + (type ? " " + type : "");
  n.textContent = text;
  void n.offsetWidth;
  n.classList.add("pop");
}
function updateCount() { $("charCount").textContent = $("code").value.length.toLocaleString() + " characters"; }
function updateUrl() {
  if (!roomId) return;
  const url = location.origin + "/room/" + roomId;
  $("shareLink").value = url;
  $("roomPill").textContent = "Room " + roomId.slice(0, 7);
  $("roomPill").classList.add("live");
  const qr = $("qr");
  const src = "/api/qr?url=" + encodeURIComponent(url);
  if (qr.getAttribute("src") !== src) {
    qr.classList.remove("pop");
    qr.src = src;
    qr.onload = () => { void qr.offsetWidth; qr.classList.add("pop"); };
  }
  qr.classList.remove("hidden");
  $("qrPlaceholder").classList.add("hidden");
}
function setCreating(on) {
  creating = on;
  $("createRoom").disabled = on;
  $("createRoom").classList.toggle("is-loading", on);
}

/* ---------- rooms ---------- */
async function createRoom() {
  if (creating) return;
  if (!curUser) { askWho(); return; }
  setCreating(true);
  try {
    const response = await fetch("/api/rooms", {
      method: "POST", headers: {"Content-Type": "application/json"},
      body: JSON.stringify({code: $("code").value, language: $("language").value})
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Could not create workspace.");
    roomId = data.id;
    isOwner = true;
    saveOwnerKey(roomId, data.ownerToken);
    history.replaceState({}, "", "/room/" + roomId);
    updateUrl();
    socket.emit("join-room", {...ident(), id: roomId, ownerToken: data.ownerToken});
    refreshMyStats();
    showNotice("Workspace created. Important: tap \"Copy owner link\" in the Owner key box and save it somewhere private. It is the only way to get owner control back if you clear this browser.", "good");
  } catch (error) {
    showNotice(error.message, "bad");
  } finally {
    setCreating(false);
  }
}
/* Owner recovery link: /room/<id>#owner=<key>. The part after # never reaches the server or any log. We store it, then remove it from the address bar. */
function absorbOwnerKeyFromUrl(id) {
  const m = location.hash.match(/^#owner=([A-Za-z0-9_-]{20,100})$/);
  if (!m) return;
  prevOwnerKey = getOwnerKey(id); saveOwnerKey(id, m[1]); recoveredKey = true;
  history.replaceState({}, "", location.pathname + location.search);
}
function joinFromPath() {
  const match = location.pathname.match(/^\/room\/([A-Za-z0-9_-]+)$/);
  if (!match) return false;
  roomId = match[1];
  absorbOwnerKeyFromUrl(roomId);
  updateUrl();
  socket.emit("join-room", {...ident(), id: roomId, ownerToken: getOwnerKey(roomId)});
  return true;
}
$("createRoom").addEventListener("click", createRoom);
$("newRoom").addEventListener("click", () => {
  if (roomId) socket.emit("leave-room", { id: roomId });   // the server drops you from the room (and its chat, if you were the last one)
  chatReset();
  roomId = null;
  isOwner = false; isLocked = false; applyPermissions(); hideOwnerKey();
  history.replaceState({}, "", "/");
  $("shareLink").value = "";
  $("qr").classList.add("hidden");
  $("qr").removeAttribute("src");
  $("qrPlaceholder").classList.remove("hidden");
  $("roomPill").textContent = "New workspace";
  $("roomPill").classList.remove("live");
  renderPeers([]);
  showNotice("Your current text remains in the editor. Create a new workspace when ready.");
  setStatus("Not connected", false);
});
$("code").addEventListener("input", () => {
  updateCount();
  const ta = $("code"), next = ta.value;
  if (next.length > MAX_CODE_LENGTH) { ta.value = shadow; showNotice("Maximum code length is 80,000 characters.", "bad"); return; }
  const op = CROT.fromDiff(shadow, next); shadow = next;
  if (!roomId) { $("syncState").textContent = "Not shared yet"; return; }
  if (isLocked && !isOwner && !can("room_edit_locked")) return;
  $("syncState").textContent = "Syncing…";
  otc.local(op);
});
$("language").addEventListener("change", () => {
  if (roomId && (!isLocked || isOwner || can("room_edit_locked"))) socket.emit("language", {id: roomId, language: $("language").value});
});
/* ---------- owner key (only ever shown to the owner, never in the page until asked for) ---------- */
function removeOwnerKey(id) {
  try { const k = JSON.parse(localStorage.getItem(OWNER_KEYS_STORAGE) || "{}"); delete k[id]; localStorage.setItem(OWNER_KEYS_STORAGE, JSON.stringify(k)); } catch {}
}
const ownerLink = () => { const t = roomId && getOwnerKey(roomId); return t ? location.origin + "/room/" + roomId + "#owner=" + t : ""; };
function hideOwnerKey() {
  clearTimeout(ownerHideTimer);
  $("ownerKeyField").value = ""; $("ownerKeyRow").classList.add("hidden");
  setLabel($("ownerKeyShow"), "Show owner key");
}
$("ownerKeyShow").addEventListener("click", () => {
  if (!$("ownerKeyRow").classList.contains("hidden")) { hideOwnerKey(); return; }
  const link = ownerLink(); if (!link) return;
  $("ownerKeyField").value = link; $("ownerKeyRow").classList.remove("hidden"); setLabel($("ownerKeyShow"), "Hide owner key");
  clearTimeout(ownerHideTimer); ownerHideTimer = setTimeout(hideOwnerKey, 30000);   // hides itself after 30 seconds
});
$("ownerKeyHide").addEventListener("click", hideOwnerKey);
$("ownerKeyCopy").addEventListener("click", async () => {
  const link = ownerLink(); if (!link) return showNotice("Owner key not found on this device.", "bad");
  try { await navigator.clipboard.writeText(link); flashLabel($("ownerKeyCopy"), "Copied"); showNotice("Owner link copied. Save it somewhere private. Anyone who has it can lock or delete this workspace.", "good"); }
  catch { $("ownerKeyShow").click(); $("ownerKeyField").select(); showNotice("Select and copy the owner link manually.", "good"); }
});
$("ownerKeyReset").addEventListener("click", () => {
  if (!roomId || !isOwner) return;
  if (!resetArmed) {                                        // first tap arms it, second tap within 6 seconds confirms
    setLabel($("ownerKeyReset"), "Tap again to confirm reset");
    resetArmed = setTimeout(() => { resetArmed = 0; setLabel($("ownerKeyReset"), "Reset owner key"); }, 6000); return;
  }
  clearTimeout(resetArmed); resetArmed = 0; setLabel($("ownerKeyReset"), "Reset owner key");
  socket.emit("rotate-owner-key", { id: roomId, ownerToken: getOwnerKey(roomId) });
});
socket.on("owner-key-rotated", d => {
  if (!d || d.id !== roomId || typeof d.ownerToken !== "string") return;
  saveOwnerKey(roomId, d.ownerToken); hideOwnerKey();
  showNotice("New owner key created. The old one no longer works. Tap \"Copy owner link\" and save the new one.", "good");
});
/* ---------- sign in (Google, GitHub, ...) and the start page ---------- */
const loginFlag = (() => { const f = new URLSearchParams(location.search).get("login"); if (f) history.replaceState({}, "", location.pathname + location.hash); return f; })();
let loginProviders = [], loginMode = "start", typerTimer = 0, typerOn = false;
const GUEST_KEY = "syncpit-guest-ok";
const guestChosen = () => { try { return sessionStorage.getItem(GUEST_KEY) === "1"; } catch { return false; } };
const PROVIDER_ICONS = {
  google: '<svg viewBox="0 0 48 48" aria-hidden="true"><path fill="#EA4335" d="M24 9.5c3.54 0 6.71 1.22 9.21 3.6l6.85-6.85C35.9 2.38 30.47 0 24 0 14.62 0 6.51 5.38 2.56 13.22l7.98 6.19C12.43 13.72 17.74 9.5 24 9.5z"/><path fill="#4285F4" d="M46.98 24.55c0-1.57-.15-3.09-.38-4.55H24v9.02h12.94c-.58 2.96-2.26 5.48-4.78 7.18l7.73 6c4.51-4.18 7.09-10.36 7.09-17.65z"/><path fill="#FBBC05" d="M10.53 28.59c-.48-1.45-.76-2.99-.76-4.59s.27-3.14.76-4.59l-7.98-6.19C.92 16.46 0 20.12 0 24c0 3.88.92 7.54 2.56 10.78l7.97-6.19z"/><path fill="#34A853" d="M24 48c6.48 0 11.93-2.13 15.89-5.81l-7.73-6c-2.15 1.45-4.92 2.3-8.16 2.3-6.26 0-11.57-4.22-13.47-9.91l-7.98 6.19C6.51 42.62 14.62 48 24 48z"/></svg>',
  github: '<svg viewBox="0 0 24 24" aria-hidden="true"><path fill="currentColor" d="M12 .5C5.65.5.5 5.65.5 12c0 5.08 3.29 9.39 7.86 10.91.58.1.79-.25.79-.56v-2c-3.2.7-3.87-1.54-3.87-1.54-.52-1.33-1.28-1.69-1.28-1.69-1.04-.71.08-.7.08-.7 1.15.08 1.76 1.18 1.76 1.18 1.03 1.76 2.69 1.25 3.35.96.1-.74.4-1.25.73-1.54-2.55-.29-5.24-1.28-5.24-5.68 0-1.25.45-2.28 1.18-3.08-.12-.29-.51-1.46.11-3.05 0 0 .97-.31 3.17 1.18a11 11 0 0 1 5.77 0c2.2-1.49 3.17-1.18 3.17-1.18.63 1.59.23 2.76.11 3.05.74.8 1.18 1.83 1.18 3.08 0 4.41-2.69 5.38-5.25 5.67.41.36.78 1.06.78 2.14v3.17c0 .31.21.67.8.56A11.5 11.5 0 0 0 23.5 12C23.5 5.65 18.35.5 12 .5z"/></svg>'
};
function confetti(x, y, n = 26) {
  if (reduceMotion) return;
  const colors = ["#ff5a67", "#ffb86b", "#7ee7c1", "#8ab4ff", "#c792ff"];
  for (let i = 0; i < n; i++) {
    const p = document.createElement("i"); p.className = "cf";
    p.style.cssText = `left:${x}px;top:${y}px;background:${colors[i % colors.length]};--dx:${(Math.random() - .5) * 340}px;--dy:${-90 - Math.random() * 230}px;--r:${Math.random() * 720 - 360}deg`;
    document.body.append(p); setTimeout(() => p.remove(), 1150);
  }
}
const TYPER_LINES = ["Code together. Live.", "Scan one QR. Everyone is in.", "Phone or desktop. Same editor.", "Run Python and JavaScript instantly."];
function startTyper() {
  if (typerOn) return; typerOn = true;
  const el = $("lgTyped"); if (reduceMotion) { el.textContent = TYPER_LINES[0]; return; }
  let line = 0, ch = 0, erasing = false;
  const step = () => {
    if (!typerOn) return;
    const text = TYPER_LINES[line];
    if (!erasing) { ch++; el.textContent = text.slice(0, ch); if (ch === text.length) { erasing = true; typerTimer = setTimeout(step, 1700); return; } typerTimer = setTimeout(step, 48); }
    else { ch--; el.textContent = text.slice(0, ch); if (ch === 0) { erasing = false; line = (line + 1) % TYPER_LINES.length; typerTimer = setTimeout(step, 320); return; } typerTimer = setTimeout(step, 22); }
  };
  el.textContent = ""; step();
}
function buildLoginButtons() {
  const box = $("lgButtons"); box.textContent = "";
  const next = roomId ? "?next=" + encodeURIComponent("/room/" + roomId) : "";
  for (const p of loginProviders) {
    const a = document.createElement("a"); a.className = "lg-btn"; a.href = "/auth/login/" + encodeURIComponent(p.id) + next;
    const ic = document.createElement("span"); ic.className = "ic";
    if (PROVIDER_ICONS[p.id]) ic.innerHTML = PROVIDER_ICONS[p.id];            // fixed icons shipped with the app, never user data
    else { const l = document.createElement("span"); l.className = "lg-letter"; l.textContent = p.label.charAt(0); ic.append(l); }
    const tx = document.createElement("span"); tx.className = "tx"; tx.textContent = (loginMode === "link" ? "Save with " : "Continue with ") + p.label;
    a.append(ic, tx); box.append(a);
    a.addEventListener("click", e => {
      if (e.metaKey || e.ctrlKey || e.shiftKey || e.button) return;
      e.preventDefault(); a.classList.add("go");
      const r = a.getBoundingClientRect(); confetti(e.clientX || r.left + r.width / 2, e.clientY || r.top + r.height / 2);
      try { if (navigator.vibrate) navigator.vibrate(12); } catch {}
      setTimeout(() => { location.href = a.href; }, reduceMotion ? 0 : 340);
    });
  }
}
function showLoginPage(mode, note) {
  const pg = $("loginPage"); loginMode = mode === "link" ? "link" : "start";
  $("lgGuest").textContent = loginMode === "link" ? "Not now" : "Continue as guest";
  const n = $("lgNote"); n.textContent = note || ""; n.classList.toggle("hidden", !note);
  buildLoginButtons();
  if (pg.classList.contains("hidden")) {
    pg.classList.remove("hidden"); document.body.classList.add("lg-open");
    document.querySelectorAll("body > header, body > main").forEach(e => { e.inert = true; });
    requestAnimationFrame(() => pg.classList.add("show"));
  }
  startTyper();
  const first = $("lgButtons").querySelector("a"); if (first) setTimeout(() => first.focus({ preventScroll: true }), 650);
}
function hideLoginPage() {
  const pg = $("loginPage"); pg.classList.remove("show"); typerOn = false; clearTimeout(typerTimer);
  document.body.classList.remove("lg-open");
  document.querySelectorAll("body > header, body > main").forEach(e => { e.inert = false; });
  setTimeout(() => pg.classList.add("hidden"), reduceMotion ? 0 : 360);
}
function askWho() {                                                      // sign in if it is set up, otherwise (or as a guest) just ask for a name
  if (loginProviders.length && !guestChosen() && !curUser) { showLoginPage("start"); return; }
  openNameDialog();
}
function updateAuthUi() {
  const signedIn = Boolean(curUser && curUser.provider);
  $("setLink").classList.toggle("hidden", !(loginProviders.length && curUser && !curUser.provider));
  $("setLogout").disabled = !signedIn;                                       // a guest has nothing to sign out of: logging out would lose the account
  $("setLogoutNote").textContent = signedIn ? "Sign out on this device. Your account stays saved." : loginProviders.length ? "You are using a guest account kept in this browser. Sign in above first; logging out now would lose it." : "You are using a guest account kept in this browser, so there is nothing to log out of.";
}
$("lgGuest").addEventListener("click", () => {
  const wasStart = loginMode === "start"; hideLoginPage();
  if (wasStart) { try { sessionStorage.setItem(GUEST_KEY, "1"); } catch {} if (!curUser) setTimeout(openNameDialog, reduceMotion ? 0 : 380); }
});
document.addEventListener("keydown", e => { if (e.key === "Escape" && !$("loginPage").classList.contains("hidden")) $("lgGuest").click(); });
$("lgButtons").addEventListener("pointermove", e => {
  const a = e.target.closest && e.target.closest(".lg-btn"); if (!a) return;
  const r = a.getBoundingClientRect(); a.style.setProperty("--mx", (e.clientX - r.left) + "px"); a.style.setProperty("--my", (e.clientY - r.top) + "px");
});
$("setLink").addEventListener("click", () => { closeSettings(); setTimeout(() => showLoginPage("link", "Sign in once to keep your name, number and workspaces on every device."), reduceMotion ? 0 : 260); });
$("setLogout").addEventListener("click", () => { if (!$("setLogout").disabled) $("logoutDlg").showModal(); });
$("logoutCancel").addEventListener("click", () => $("logoutDlg").close());
$("logoutGo").addEventListener("click", async () => {
  $("logoutGo").disabled = true;
  try { await fetch("/api/auth/logout", { method: "POST" }); } catch {}
  try { sessionStorage.removeItem(GUEST_KEY); } catch {}
  location.href = "/";
});
function celebrate(name) {
  showNotice("Welcome" + (name ? ", " + name : "") + "! You are signed in.", "good");
  if (reduceMotion) return;
  const w = innerWidth; [0.25, 0.5, 0.75].forEach((f, i) => setTimeout(() => confetti(w * f, innerHeight * 0.3, 30), i * 160));
}

/* ---------- my saved workspaces ---------- */
const myRoomsList = $("myRoomsList");
const localOwnerIds = () => { try { return Object.keys(JSON.parse(localStorage.getItem(OWNER_KEYS_STORAGE) || "{}")).filter(k => /^[A-Za-z0-9_-]{6,40}$/.test(k)).slice(0, 50); } catch { return []; } };
function agoText(ms) {
  if (!ms) return "";
  const s = Math.max(0, Math.round((Date.now() - ms) / 1000));
  if (s < 60) return "just now"; if (s < 3600) return Math.floor(s / 60) + " min ago";
  if (s < 86400) return Math.floor(s / 3600) + " h ago"; return Math.floor(s / 86400) + " d ago";
}
function myRoomRow(r, localIds) {
  const li = document.createElement("li"); li.className = "my-room";
  const top = document.createElement("div"); top.className = "mr-top";
  const code = document.createElement("span"); code.className = "mr-code" + (r.preview ? "" : " empty"); code.textContent = r.preview || "(empty workspace)";
  const openBtn = document.createElement("button"); openBtn.type = "button"; const here = r.id === roomId;
  openBtn.textContent = here ? "Current" : "Open"; openBtn.disabled = here;
  openBtn.addEventListener("click", () => {
    if (!roomId && $("code").value.trim() && !confirm("The code in your editor is not saved in a workspace and will be lost. Open anyway?")) return;
    location.href = "/room/" + encodeURIComponent(r.id);
  });
  top.append(code, openBtn);
  const meta = document.createElement("div"); meta.className = "mr-meta";
  meta.textContent = [r.language, r.updatedAt ? "updated " + agoText(r.updatedAt) : "", r.active ? r.active + " online now" : "", r.locked ? "locked" : ""].filter(Boolean).join(" · ");
  li.append(top, meta);
  const hasKey = localIds.includes(r.id), b = document.createElement("div"); b.className = "mr-badge";
  b.textContent = hasKey ? "You are the owner on this device" : "Created by you. Open your owner link on this device to lock or delete it.";
  li.append(b);
  return li;
}
async function loadMyRooms() {
  const msg = $("myRoomsMsg"); myRoomsList.textContent = ""; msg.textContent = "Loading…";
  try {
    const localIds = localOwnerIds();
    const r = await fetch("/api/rooms/mine", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ ids: localIds }) });
    if (!r.ok) throw new Error(); const d = await r.json();
    (d.rooms || []).forEach(x => myRoomsList.append(myRoomRow(x, localIds)));
    msg.textContent = d.rooms && d.rooms.length ? "" : "No saved workspaces yet. Create one and it will show up here.";
  } catch { msg.textContent = "Could not load your workspaces. Try again."; }
}

/* ---------- workspace counts ---------- */
function statsText(st) {
  if (!st) return "";
  const a = (st.active || 0) + " active";
  return st.created == null ? a : st.created + " created · " + st.saved + " saved · " + a;
}
function statsNode(st) {
  const parts = statsText(st).split(" · "), el = document.createElement("span");
  parts.forEach((p, i) => { if (i) el.append(" · "); const [n, ...rest] = p.split(" "); const b = document.createElement("b"); b.textContent = n; el.append(b, " " + rest.join(" ")); });
  return el;
}
let myStatsTimer = 0;
function refreshMyStats() {
  clearTimeout(myStatsTimer);
  myStatsTimer = setTimeout(async () => {
    const box = $("myStats");
    if (!curUser) { box.classList.add("hidden"); return; }
    try {
      const r = await fetch("/api/me/stats", { cache: "no-store" }); if (!r.ok) throw new Error();
      const st = await r.json(); box.textContent = ""; box.append("Your workspaces: ", statsNode(st)); box.classList.remove("hidden");
    } catch { box.classList.add("hidden"); }
  }, 400);
}

/* ---------- maintenance mode ---------- */
const maintLeft = () => Math.max(0, (maint.endsAt || 0) - (Date.now() + maintOffset));
const fmtLeft = ms => { const t = Math.ceil(ms / 1000); return Math.floor(t / 60) + ":" + String(t % 60).padStart(2, "0"); };
const isStaff = () => Boolean(curUser && curUser.dev);
const ownerSaveDlg = $("ownerSaveDlg"), maintCtl = $("maintCtl");
ownerSaveDlg.addEventListener("cancel", e => e.preventDefault());              // mandatory: Esc / back cannot dismiss it
function showMaintPage() {
  $("maintPage").classList.remove("hidden");
  if (!maintPoll) maintPoll = setInterval(async () => {                         // come back automatically when the site is on again
    try { const r = await fetch("/api/status", { cache: "no-store" }); const j = await r.json(); if (!j.maintenance) location.reload(); } catch {}
  }, 10000);
}
function maybePromptOwner() {
  if (maint.phase === "off" || ownerSaved || ownerSaveDlg.open) return;
  if (!(isOwner && roomId && getOwnerKey(roomId))) return;
  $("ownerSaveDone").disabled = true; $("ownerSaveField").classList.add("hidden"); $("ownerSaveField").value = "";
  $("ownerSaveMsg").textContent = "Copying your owner link…"; setLabel($("ownerSaveCopy"), "Copy owner link");
  try { if (navigator.vibrate) navigator.vibrate([200, 100, 200]); } catch {}
  document.title = "⚠ Save your owner link · SyncPit";
  if (typeof ownerSaveDlg.showModal === "function") ownerSaveDlg.showModal();
  copyOwnerForSave(true);
}
async function copyOwnerForSave(auto) {
  const link = ownerLink();
  if (!link) { $("ownerSaveMsg").textContent = "Owner key not found on this device."; $("ownerSaveDone").disabled = false; return; }
  try {
    await navigator.clipboard.writeText(link);
    $("ownerSaveMsg").textContent = "Copied. Your owner link is on your clipboard. Paste it somewhere private before you continue.";
    setLabel($("ownerSaveCopy"), "Copy again"); $("ownerSaveDone").disabled = false;
  } catch {
    $("ownerSaveField").value = link; $("ownerSaveField").classList.remove("hidden");
    $("ownerSaveMsg").textContent = auto ? "Tap Copy owner link. If it does not copy, press and hold the link below and copy it." : "Could not copy automatically. Press and hold the link below and copy it.";
    $("ownerSaveDone").disabled = !auto ? false : $("ownerSaveDone").disabled;
    if (!auto) $("ownerSaveField").select();
  }
}
$("ownerSaveCopy").addEventListener("click", () => copyOwnerForSave(false));
$("ownerSaveDone").addEventListener("click", () => {
  ownerSaved = true; $("ownerSaveField").value = ""; document.title = "SyncPit — Shared coding room"; ownerSaveDlg.close();
});
function renderMaintCtl() {
  const left = maint.phase === "warning" ? " Going down in " + fmtLeft(maintLeft()) + "." : "";
  $("maintStatus").textContent = maint.phase === "off" ? "The site is running normally. Starting maintenance warns every visitor first, tells workspace owners to save their owner link, then shows everyone else a plain \"temporarily unavailable\" page. You can still open the site."
    : maint.phase === "warning" ? "Maintenance is about to start" + (maint.by ? ", started by " + maint.by : "") + "." + left : "Maintenance is ON" + (maint.by ? ", started by " + maint.by : "") + ". Everyone except you sees the unavailable page.";
  $("maintStartRow").classList.toggle("hidden", maint.phase !== "off");
  $("maintStart").classList.toggle("hidden", maint.phase !== "off");
  $("maintOff").classList.toggle("hidden", maint.phase === "off");
  setLabel($("maintOff"), maint.phase === "warning" ? "Cancel countdown" : "Turn site back on");
}
function applyMaintenance(st) {
  if (st && st.phase) { maint = { phase: st.phase, endsAt: st.endsAt || 0, by: st.by || "" }; if (st.now) maintOffset = st.now - Date.now(); }
  clearInterval(maintClock); maintClock = 0;
  const bar = $("maintBar"), btn = $("maintBtn");
  setLabel(btn, maint.phase === "off" ? "Maintenance" : maint.phase === "warning" ? "Maintenance · soon" : "Maintenance · ON");
  if (maint.phase === "off") {
    bar.classList.add("hidden");
    if (ownerSaveDlg.open) { ownerSaveDlg.close(); document.title = "SyncPit — Shared coding room"; }
    ownerSaved = false; $("maintPage").classList.add("hidden");
    if (maintCtl.open) renderMaintCtl();
    return;
  }
  if (maint.phase === "warning") {
    const tick = () => {
      bar.textContent = "The site goes down for maintenance in " + fmtLeft(maintLeft()) + ". Your code is saved automatically.";
      $("ownerSaveLeft").textContent = fmtLeft(maintLeft());
      if (maintCtl.open) renderMaintCtl();
    };
    bar.classList.remove("hidden"); tick(); maintClock = setInterval(tick, 1000);
    maybePromptOwner();
    return;
  }
  // on
  if (isStaff()) { bar.textContent = "Maintenance is ON" + (st && st.by ? ", started by " + st.by : "") + ". Everyone else sees the unavailable page. Use the Maintenance button to turn it off."; bar.classList.remove("hidden"); if (maintCtl.open) renderMaintCtl(); }
  else { bar.classList.add("hidden"); showMaintPage(); }       // an owner who has not saved yet keeps the dialog on top of this page
}
socket.on("maintenance", applyMaintenance);
socket.on("connect_error", err => { if (err && err.message === "maintenance") { maint = { phase: "on", endsAt: 0 }; showMaintPage(); } });
$("maintReload").addEventListener("click", () => location.reload());
$("maintBtn").addEventListener("click", () => { renderMaintCtl(); maintCtl.showModal(); });
$("maintClose").addEventListener("click", () => maintCtl.close());
$("maintStart").addEventListener("click", () => {
  if (!startArmed) {                                                          // first tap arms it, second tap starts it
    setLabel($("maintStart"), "Tap again to start"); startArmed = setTimeout(() => { startArmed = 0; setLabel($("maintStart"), "Start maintenance"); }, 5000); return;
  }
  clearTimeout(startArmed); startArmed = 0; setLabel($("maintStart"), "Start maintenance");
  socket.emit("maint-set", { action: "start", seconds: Number($("maintDelay").value) });
});
$("maintOff").addEventListener("click", () => socket.emit("maint-set", { action: "off" }));
$("copyLink").addEventListener("click", async () => {
  if (!$("shareLink").value) return showNotice("Create a workspace first.");
  try { await navigator.clipboard.writeText($("shareLink").value); flashLabel($("copyLink"), "Copied"); showNotice("Workspace link copied.", "good"); }
  catch { $("shareLink").select(); showNotice("Select and copy the link manually."); }
});
$("copyCode").addEventListener("click", async () => {
  try { await navigator.clipboard.writeText($("code").value); flashLabel($("copyCode"), "Copied"); showNotice("Code copied to clipboard.", "good"); }
  catch { $("code").focus(); $("code").select(); showNotice("Code selected. Copy it with Ctrl+C (or Cmd+C on Mac)."); }
});
$("lockBtn").addEventListener("click", () => {
  if (!roomId || !(isOwner || can("room_lock"))) return;
  socket.emit("set-lock", {...ident(), id: roomId, ownerToken: getOwnerKey(roomId), locked: !isLocked});
});

/* ---------- socket events ---------- */
socket.on("connect", () => {
  setStatus("Connected", true);
  if (roomId) socket.emit("join-room", {...ident(), id: roomId, ownerToken: getOwnerKey(roomId)});
});
socket.on("disconnect", () => { setStatus("Reconnecting…", false); renderPeers([]); });
socket.on("room-state", state => loadState(state));
socket.on("resync", state => { loadState(state); showNotice("Your last change could not be merged, so the latest saved version was loaded.", "bad"); });
function loadState(state) {
  roomId = state.id; isOwner = Boolean(state.isOwner); isLocked = Boolean(state.locked);
  shadow = state.code; $("code").value = state.code; $("language").value = state.language || "Plain text";
  otc.reset(state.rev);
  updateCount(); updateUrl(); applyPermissions(); scheduleHighlight();
  setStatus(state.peers.length + " connected", true); renderPeers(state.peers);
  chatOnRoom(state);
  maybePromptOwner();
  if (recoveredKey) {
    recoveredKey = false;
    prevOwnerKey = "";
    if (isOwner) { showNotice("Owner access restored on this device. Only the owner link can do this, so keep it private.", "good"); return; }
    if (prevOwnerKey) { saveOwnerKey(roomId, prevOwnerKey); socket.emit("join-room", {...ident(), id: roomId, ownerToken: prevOwnerKey}); }   // keep the key we already had
    else removeOwnerKey(roomId);
    prevOwnerKey = ""; applyPermissions();
    showNotice("That owner link is not valid for this workspace. It may have been reset.", "bad"); return;
  }
  if (!isLocked) showNotice(isOwner ? "Owner workspace connected. You can share the QR/link and control editing access." : "Connected to shared workspace. Edits sync live and are saved.", "good");
}
socket.on("presence", data => { setStatus(data.peers.length + " connected", true); renderPeers(data.peers); });
socket.on("op", d => otc.remote(d.rev, d.op));
socket.on("ack", d => { otc.ack(d.rev); if (!otc.inflight) $("syncState").textContent = "Synced and saved"; });
socket.on("language", d => { $("language").value = d.language || "Plain text"; scheduleHighlight(); });
socket.on("lock-state", data => {
  isLocked = Boolean(data.locked);
  if (typeof data.isOwner === "boolean") isOwner = data.isOwner;
  applyPermissions();
  if (isOwner) showNotice(isLocked ? "Editing locked. Visitors can view and copy code; only you can edit." : "Editing unlocked. Everyone with the link can edit again.", "good");
});
$("deleteRoom").addEventListener("click", () => {
  if (!roomId || !(isOwner || can("room_delete"))) return;
  $("delConfirm").classList.remove("is-loading"); $("delDlg").showModal();
});
$("delCancel").addEventListener("click", () => $("delDlg").close());
$("delConfirm").addEventListener("click", () => {
  if (!roomId || !(isOwner || can("room_delete"))) return;
  $("delConfirm").classList.add("is-loading");
  socket.emit("delete-room", { id: roomId, ownerToken: getOwnerKey(roomId) });
});
socket.on("permission-error", () => { if ($("delDlg").open) { $("delDlg").close(); } });
socket.on("room-deleted", () => {
  refreshMyStats();
  if ($("delDlg").open) $("delDlg").close();
  try { const k = JSON.parse(localStorage.getItem(OWNER_KEYS_STORAGE) || "{}"); delete k[roomId]; localStorage.setItem(OWNER_KEYS_STORAGE, JSON.stringify(k)); } catch {}
  otc.reset(0); $("newRoom").click();
  showNotice("This workspace was deleted. Its link no longer works. The text is still in your editor.", "bad");
});
socket.on("permission-error", message => showNotice(message, "bad"));
socket.on("room-error", message => {
  showNotice(message, "bad");
  setStatus("Room unavailable", false);
});


const hlCode = document.querySelector("#hl code");
let hlFrame = 0;
function syncScroll() {
  hlCode.style.transform = `translate(${-$("code").scrollLeft}px, ${-$("code").scrollTop}px)`;
}
function renderHighlight() {
  hlFrame = 0;
  const code = $("code").value;
  let name = $("language").value;
  if (name === "Auto detect") name = detectLanguage(code);
  hlCode.innerHTML = highlight(code, name) + "\n";
  syncScroll();
}
function scheduleHighlight() { if (!hlFrame) hlFrame = requestAnimationFrame(renderHighlight); }
$("code").addEventListener("input", scheduleHighlight);
$("code").addEventListener("scroll", syncScroll, { passive: true });
$("language").addEventListener("change", scheduleHighlight);
if (window.ResizeObserver) new ResizeObserver(syncScroll).observe($("code"));

/* ---------- terms dialog ---------- */
const terms = $("terms");
$("termsBtn").addEventListener("click", () => terms.showModal());
/* ---------- play phonk: public for everyone; a floating player you can drag, minimize and close without stopping the music ---------- */
/* Songs come from two places: your own files (/phonk/phonks.json -> /phonk/<name>.mp3) and an online search through this server (Audius). */
const pw = $("phonkWin"), phonkList = $("phonkList"), phonkResults = $("phonkResults"), phonkMsg = $("phonkMsg"), phonkPlayer = $("phonkPlayer"), phonkBubble = $("phonkBubble"), phonkBar = $("phonkBar");
let phonkNames = null, phonkNow = null, phonkItem = null, pwOpen = false, pwPos = null, pwDrag = null, phonkSeq = 0, phonkTimer = 0, phonkFirst = true;
const phonkRows = new Map();                                              // key -> <li>
const fmtT = t => (isFinite(t) && t > 0) ? Math.floor(t / 60) + ":" + String(Math.floor(t % 60)).padStart(2, "0") : "0:00";
const phonkIsPlaying = () => phonkNow !== null && !phonkPlayer.paused && !phonkPlayer.ended;
function phonkNote(t, bad) { phonkMsg.textContent = t || ""; phonkMsg.classList.toggle("bad", Boolean(bad)); }
function phonkSync() {
  const playing = phonkIsPlaying();
  for (const [k, li] of phonkRows) { li.classList.toggle("active", k === phonkNow); li.classList.toggle("playing", k === phonkNow && playing); li.setAttribute("aria-pressed", String(k === phonkNow && playing)); }
  $("phonkBtn").classList.toggle("playing", playing); pw.classList.toggle("playing", playing);
  $("phonkBtn").querySelector(".label").textContent = playing ? "Now playing" : "Play phonk";
  phonkBubble.classList.toggle("show", !pwOpen && phonkNow !== null); phonkBubble.classList.toggle("playing", playing);
  $("phonkNowName").textContent = phonkItem ? phonkItem.title : "Nothing playing";
  $("phonkToggle").disabled = $("phonkStop").disabled = phonkNow === null;
}
function phonkProgress() {
  const d = phonkPlayer.duration, t = phonkPlayer.currentTime, pct = d > 0 ? Math.min(100, t / d * 100) : 0;
  $("phonkFill").style.width = pct + "%"; $("phonkProg").setAttribute("aria-valuenow", String(Math.round(pct)));
  $("phonkTime").textContent = phonkNow === null ? "0:00" : fmtT(t) + (d > 0 && isFinite(d) ? " / " + fmtT(d) : "");
}
function phonkToggle() {
  if (phonkNow === null) return;
  if (phonkPlayer.paused) { if (phonkPlayer.ended) phonkPlayer.currentTime = 0; phonkPlayer.play().catch(() => {}); } else phonkPlayer.pause();
}
function phonkPlay(item) {
  if (phonkNow === item.key) { phonkToggle(); return; }                  // same one: pause / resume
  phonkNow = item.key; phonkItem = item; phonkNote(""); phonkPlayer.src = item.src;
  phonkPlayer.play().catch(() => {}); phonkSync(); phonkProgress();
  if ("mediaSession" in navigator && window.MediaMetadata) navigator.mediaSession.metadata = new MediaMetadata({ title: item.title, artist: item.artist || "SyncPit" });
}
function phonkStop() { phonkPlayer.pause(); phonkPlayer.removeAttribute("src"); phonkPlayer.load(); phonkNow = null; phonkItem = null; phonkSync(); phonkProgress(); }
for (const ev of ["play", "pause", "ended"]) phonkPlayer.addEventListener(ev, phonkSync);
for (const ev of ["timeupdate", "loadedmetadata", "durationchange"]) phonkPlayer.addEventListener(ev, phonkProgress);
phonkPlayer.addEventListener("error", () => {
  if (phonkNow === null || !phonkPlayer.getAttribute("src")) return;
  const it = phonkItem; phonkNow = null; phonkItem = null; phonkSync(); phonkProgress();
  phonkNote(it && it.online ? "Couldn\u2019t play \u201c" + it.title + "\u201d. Try another song." : "Couldn\u2019t play \u201c" + (it ? it.title : "") + "\u201d. Check that " + (it ? it.title : "") + ".mp3 is in the phonk folder.", true);
});
if ("mediaSession" in navigator) { try { navigator.mediaSession.setActionHandler("play", phonkToggle); navigator.mediaSession.setActionHandler("pause", phonkToggle); navigator.mediaSession.setActionHandler("stop", phonkStop); } catch {} }

function phonkRow(item, i) {
  const li = document.createElement("li"); li.className = "phonk-row"; li.tabIndex = 0; li.setAttribute("role", "button"); li.style.setProperty("--i", Math.min(i, 12));
  const eq = document.createElement("span"); eq.className = "eq"; eq.setAttribute("aria-hidden", "true"); eq.append(document.createElement("i"), document.createElement("i"), document.createElement("i"));
  const t = document.createElement("span"); t.className = "pn";
  const ti = document.createElement("span"); ti.className = "pt"; ti.textContent = item.title; t.append(ti);
  if (item.artist) { const ar = document.createElement("small"); ar.className = "pa"; ar.textContent = item.artist; t.append(ar); }
  li.append(eq, t);
  if (item.duration) { const d = document.createElement("span"); d.className = "pd"; d.textContent = fmtT(item.duration); li.append(d); }
  li.addEventListener("click", () => phonkPlay(item));
  li.addEventListener("keydown", e => { if (e.key === "Enter" || e.key === " ") { e.preventDefault(); phonkPlay(item); } });
  phonkRows.set(item.key, li); return li;
}
async function phonkLoad() {
  if (phonkNames) return;
  try {
    const r = await fetch("/phonk/phonks.json"); if (!r.ok) throw 0;
    const d = await r.json(); phonkNames = (Array.isArray(d) ? d : []).map(String).map(x => x.trim()).filter(Boolean).slice(0, 200);
  } catch { phonkNames = []; }
  phonkList.textContent = "";
  phonkNames.forEach((n, i) => phonkList.append(phonkRow({ key: "local:" + n, title: n, src: "/phonk/" + encodeURIComponent(n) + ".mp3" }, i)));
  $("phonkMineH").classList.toggle("hidden", !phonkNames.length);
  phonkSync();
  if (phonkFirst) { phonkFirst = false; phonkSearch("phonk", true); }       // show something to play right away
}
/* online search */
function phonkSkeleton() { phonkResults.textContent = ""; for (let i = 0; i < 4; i++) { const li = document.createElement("li"); li.className = "phonk-row skel"; li.style.setProperty("--i", i); phonkResults.append(li); } $("phonkResH").classList.remove("hidden"); }
async function phonkSearch(q, quiet) {
  q = String(q || "").trim(); const seq = ++phonkSeq;
  for (const [k] of phonkRows) if (k.startsWith("audius:")) phonkRows.delete(k);
  if (!q) { phonkResults.textContent = ""; $("phonkResH").classList.add("hidden"); phonkNote(""); return; }
  phonkNote(""); phonkSkeleton(); $("phonkSearch").classList.add("busy");
  try {
    const r = await fetch("/api/music/search?q=" + encodeURIComponent(q)), d = await r.json().catch(() => ({}));
    if (seq !== phonkSeq) return;
    if (!r.ok) throw new Error(d.error || (r.status === 429 ? "Too many searches. Wait a moment." : "Search isn\u2019t available right now."));
    phonkResults.textContent = "";
    const tracks = Array.isArray(d.tracks) ? d.tracks : [];
    tracks.forEach((t, i) => phonkResults.append(phonkRow({ key: "audius:" + t.id, title: t.title, artist: t.artist, duration: t.duration, online: true, src: "/api/music/stream/" + encodeURIComponent(t.id) }, i)));
    $("phonkResH").classList.toggle("hidden", !tracks.length);
    phonkNote(tracks.length ? "" : "No songs found for \u201c" + q + "\u201d.");
    phonkSync();
  } catch (e) {
    if (seq !== phonkSeq) return;
    phonkResults.textContent = ""; $("phonkResH").classList.add("hidden"); if (!quiet) phonkNote(e.message, true);
  } finally { if (seq === phonkSeq) $("phonkSearch").classList.remove("busy"); }
}
$("phonkSearch").addEventListener("submit", e => { e.preventDefault(); clearTimeout(phonkTimer); phonkSearch($("phonkQ").value); });
$("phonkQ").addEventListener("input", () => { clearTimeout(phonkTimer); const v = $("phonkQ").value.trim(); phonkTimer = setTimeout(() => { if (v.length >= 2 || !v) phonkSearch(v || "phonk"); }, 550); });

/* window: open / close / minimize / drag. Closing only hides the window; the <audio> lives outside it, so the music keeps going. */
function pwApply(x, y) {
  const w = pw.offsetWidth, h = pw.offsetHeight;
  x = Math.min(Math.max(8, x), Math.max(8, innerWidth - w - 8)); y = Math.min(Math.max(8, y), Math.max(8, innerHeight - h - 8));
  pwPos = { x, y }; pw.classList.add("free"); pw.style.setProperty("--x", x + "px"); pw.style.setProperty("--y", y + "px");
}
function pwShow(open) {
  pwOpen = open; pw.classList.toggle("show", open); pw.inert = !open; pw.setAttribute("aria-hidden", String(!open));
  $("phonkBtn").setAttribute("aria-expanded", String(open)); phonkSync();
  if (open) { phonkLoad(); if (pwPos) pwApply(pwPos.x, pwPos.y); }
}
function pwMin(min) { pw.classList.toggle("min", min); $("phonkFold").inert = min; $("phonkMin").setAttribute("aria-expanded", String(!min)); $("phonkMin").setAttribute("aria-label", min ? "Expand" : "Minimize"); }
$("phonkBtn").addEventListener("click", () => pwShow(!pwOpen));
phonkBubble.addEventListener("click", () => pwShow(true));
$("phonkX").addEventListener("click", () => { pwShow(false); $("phonkBtn").focus({ preventScroll: true }); });
$("phonkMin").addEventListener("click", () => pwMin(!pw.classList.contains("min")));
$("phonkToggle").addEventListener("click", phonkToggle);
$("phonkStop").addEventListener("click", phonkStop);
pw.addEventListener("keydown", e => { if (e.key === "Escape") { e.stopPropagation(); pwShow(false); $("phonkBtn").focus({ preventScroll: true }); } });
phonkBar.addEventListener("dblclick", e => { if (!e.target.closest("button")) pwMin(!pw.classList.contains("min")); });
phonkBar.addEventListener("pointerdown", e => {
  if (e.button !== 0 || e.target.closest("button")) return;
  const r = pw.getBoundingClientRect(); pwApply(r.left, r.top);
  pwDrag = { dx: e.clientX - r.left, dy: e.clientY - r.top }; pw.classList.add("dragging"); phonkBar.setPointerCapture(e.pointerId);
});
phonkBar.addEventListener("pointermove", e => { if (pwDrag) pwApply(e.clientX - pwDrag.dx, e.clientY - pwDrag.dy); });
for (const ev of ["pointerup", "pointercancel"]) phonkBar.addEventListener(ev, () => { pwDrag = null; pw.classList.remove("dragging"); });
addEventListener("resize", () => { if (pwPos) pwApply(pwPos.x, pwPos.y); });
if (window.ResizeObserver) new ResizeObserver(() => { if (pwPos && !pwDrag) pwApply(pwPos.x, pwPos.y); }).observe(pw);   // keeps it on screen when it grows or shrinks

/* seek bar */
const prog = $("phonkProg");
function seekAt(e) { const r = prog.getBoundingClientRect(), d = phonkPlayer.duration; if (phonkNow !== null && d > 0) { phonkPlayer.currentTime = Math.min(1, Math.max(0, (e.clientX - r.left) / r.width)) * d; phonkProgress(); } }
let seeking = false;
prog.addEventListener("pointerdown", e => { seeking = true; prog.setPointerCapture(e.pointerId); seekAt(e); });
prog.addEventListener("pointermove", e => { if (seeking) seekAt(e); });
for (const ev of ["pointerup", "pointercancel"]) prog.addEventListener(ev, () => { seeking = false; });
phonkSync(); phonkProgress();

/* ---------- feedback: sent to the developer's Discord by the server ---------- */
const fbDlg = $("feedbackDlg"), fbText = $("fbText"), fbMsg = $("fbMsg");
let fbKind = "idea", fbBusy = false;
function fbNote(t, kind) { fbMsg.textContent = t || ""; fbMsg.className = "fb-msg" + (kind ? " " + kind : ""); }
function closeFb() {
  if (reduceMotion) return fbDlg.close();
  fbDlg.classList.add("closing");
  setTimeout(() => { fbDlg.close(); fbDlg.classList.remove("closing"); }, 220);
}
$("feedbackBtn").addEventListener("click", () => {
  if (!curUser) { askWho(); return; }                       // feedback needs a name so it is clear who sent it
  fbNote(""); fbDlg.showModal(); fbText.focus();
});
$("fbKinds").addEventListener("click", e => {
  const c = e.target.closest(".fb-chip"); if (!c) return;
  fbKind = c.dataset.kind;
  $("fbKinds").querySelectorAll(".fb-chip").forEach(x => { const on = x === c; x.classList.toggle("on", on); x.setAttribute("aria-checked", String(on)); });
});
fbText.addEventListener("input", () => { $("fbCount").textContent = fbText.value.length + " / 1000"; fbNote(""); });
$("fbCancel").addEventListener("click", closeFb);
fbDlg.addEventListener("cancel", e => { e.preventDefault(); if (!fbBusy) closeFb(); });
fbDlg.addEventListener("click", e => { if (e.target === fbDlg && !fbBusy) closeFb(); });
$("fbSend").addEventListener("click", async () => {
  if (fbBusy) return;
  const message = fbText.value.trim();
  if (message.length < 20) { fbNote("Please write at least 20 characters so we can understand (" + message.length + "/20).", "bad"); fbText.focus(); return; }
  fbBusy = true; $("fbSend").disabled = true; $("fbSend").classList.add("is-loading"); fbNote("Sending\u2026");
  try {
    const r = await fetch("/api/feedback", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ kind: fbKind, message }) }), d = await r.json().catch(() => ({}));
    if (!r.ok) throw new Error(d.error || "Couldn't send your feedback. Please try again.");
    fbText.value = ""; $("fbCount").textContent = "0 / 1000"; fbNote("Thank you! Your feedback was sent.", "ok");
    flashLabel($("feedbackBtn"), "Thanks!", 2200);
    setTimeout(() => { if (fbDlg.open) closeFb(); }, 1100);
  } catch (e) { fbNote(e.message, "bad"); }
  finally { fbBusy = false; $("fbSend").disabled = false; $("fbSend").classList.remove("is-loading"); }
});

function closeTerms() {
  if (reduceMotion) return terms.close();
  terms.classList.add("closing");
  setTimeout(() => { terms.close(); terms.classList.remove("closing"); }, 220);
}
$("closeTerms").addEventListener("click", closeTerms);
terms.addEventListener("cancel", e => { e.preventDefault(); closeTerms(); });
terms.addEventListener("click", e => { if (e.target === terms) closeTerms(); });

/* ---------- footer credit: split into words for the reveal ---------- */
(() => {
  const el = $("crown");
  el.innerHTML = el.textContent.split(" ").map((w, i) => `<span class="w" style="--i:${i}">${w}</span>`).join(" ");
})();

/* ---------- console: runs JavaScript and Python in a sandboxed page ---------- */
const RUNTIME = { JavaScript: "js", TypeScript: "ts", Python: "py", SQL: "sql", Lua: "lua", HTML: "html", CSS: "css" };
let view = "code", previewFrame = null, previewTimer = 0;
let runner = null, runnerReady = null, runSeq = 0, activeRun = null;
let stdinLines = [], waitingInput = false;       // console input: lines for input() / prompt(); the program re-runs with them when it asks for more
const out = $("consoleOut");
function addLine(kind, text, line) {
  const hint = out.querySelector(".cl-hint"); if (hint) hint.remove();
  const row = document.createElement("div"); row.className = "cl cl-" + kind;
  const span = document.createElement("span"); span.textContent = text; row.appendChild(span);
  if (line) { const b = document.createElement("button"); b.className = "cl-line"; b.textContent = "line " + line; b.addEventListener("click", () => jumpToLine(line)); row.appendChild(b); }
  out.appendChild(row); out.scrollTop = out.scrollHeight;
}
function jumpToLine(n) {
  const ta = $("code"), lines = ta.value.split("\n"); let start = 0;
  for (let i = 0; i < Math.min(n - 1, lines.length - 1); i++) start += lines[i].length + 1;
  const end = start + (lines[Math.min(n, lines.length) - 1] || "").length;
  ta.focus(); ta.setSelectionRange(start, end);
  ta.scrollTo({ top: Math.max(0, (n - 4) * 21.45), behavior: reduceMotion ? "auto" : "smooth" });
}
function resolvedLanguage() { const v = $("language").value; return v === "Auto detect" ? detectLanguage($("code").value) : v; }
function ensureRunner() {
  if (runnerReady) return runnerReady;
  runner = document.createElement("iframe");
  runner.src = "/runner"; runner.className = "runner-frame"; runner.title = "Sandboxed code runner";
  runner.setAttribute("sandbox", "allow-scripts");
  runnerReady = new Promise((res, rej) => { runner._ready = res; setTimeout(() => rej(new Error("The code runner did not start. Check your connection and try again.")), 20000); });
  document.body.appendChild(runner);
  return runnerReady;
}
function setRunning(on) {
  $("runBtn").disabled = on; $("runBtn").classList.toggle("is-loading", on); $("stopBtn").classList.toggle("hidden", !on);
}
window.addEventListener("message", e => {
  const m = e.data || {};
  if (previewFrame && e.source === previewFrame.contentWindow) { if (m.type === "ready") previewFrame._res(); return; }
  if (!runner || e.source !== runner.contentWindow) return;      // only our own sandboxed frames
  if (m.type === "ready" && runner._ready) runner._ready();
  else if (m.type === "out" && activeRun && m.id === activeRun.id) addLine(["log", "error", "info", "input"].includes(m.t) ? m.t : "log", (m.t === "input" ? "› " : "") + String(m.text), Number(m.line) || 0);
  else if (m.type === "phase" && activeRun && m.id === activeRun.id) armWatchdog(m.id, m.phase === "loading" ? 30 * 60 * 1000 : 45000);
  else if (m.type === "pystate" && !activeRun) { if (m.state === "loading") addLine("info", "Downloading Python in the background (first time only, about 10 MB)…"); else if (m.state === "ready") addLine("info", "Python is ready."); else if (m.state === "error") addLine("error", String(m.text || "Couldn’t download Python.")); }
  else if (m.type === "done" && activeRun && m.id === activeRun.id) {
    clearTimeout(activeRun.wd);
    const needs = !!m.needInput, extra = stdinLines.length > (activeRun.sent || 0);
    waitingInput = needs; if (!needs) stdinLines = [];
    if (needs) addLine("info", extra ? "Using the input you typed…" : "Waiting for input. Type it below and press Enter.");
    else addLine(m.ok ? "meta" : "error", (m.ok ? "Finished in " : m.stopped ? "Stopped after " : "Failed after ") + (m.ms || 0) + " ms");
    activeRun = null; setRunning(false);
    if (needs && extra) runCode({ replay: true }); else if (needs) $("consoleIn").focus();
  }
});
function destroyRunner() { if (runner) runner.remove(); runner = null; runnerReady = null; pyPreloaded = false; }
function previewHtml() {
  const name = resolvedLanguage(), code = $("code").value;
  if (name === "HTML") return code;
  if (name === "CSS") return '<!doctype html><meta charset="utf-8"><style>body{font-family:system-ui,sans-serif;padding:24px}</style><style>' + code.replace(/<\/style/gi, "") + '</style><h1>Heading</h1><p>A paragraph with a <a href="#">link</a>.</p><button>Button</button><ul><li>One</li><li>Two</li></ul>';
  return null;
}
async function renderPreview() {
  const html = previewHtml();
  if (!previewFrame) {
    previewFrame = document.createElement("iframe");
    previewFrame.src = "/runner"; previewFrame.className = "preview-frame"; previewFrame.title = "Sandboxed preview";
    previewFrame.setAttribute("sandbox", "allow-scripts");
    previewFrame._ready = new Promise(r => { previewFrame._res = r; });
    $("previewBox").appendChild(previewFrame);
  }
  $("previewHint").classList.toggle("hidden", html !== null); previewFrame.classList.toggle("hidden", html === null);
  if (html === null) return;
  await previewFrame._ready;
  previewFrame.contentWindow.postMessage({ type: "preview", html }, "*");
}
function schedulePreview() { if (view !== "preview") return; clearTimeout(previewTimer); previewTimer = setTimeout(renderPreview, 350); }
function showView(v) {
  view = v;
  $("viewCode").setAttribute("aria-pressed", String(v === "code")); $("viewPreview").setAttribute("aria-pressed", String(v === "preview"));
  document.querySelector(".editor-wrap").classList.toggle("hidden", v !== "code"); $("previewBox").classList.toggle("hidden", v !== "preview");
  if (v === "preview") renderPreview();
}
$("viewCode").addEventListener("click", () => showView("code"));
$("viewPreview").addEventListener("click", () => showView("preview"));
$("code").addEventListener("input", schedulePreview);
$("language").addEventListener("change", () => { if (view === "preview") renderPreview(); });
/* Start downloading Python as soon as the code looks like Python, so it is usually ready before Run is pressed. */
let pyPreloaded = false, preloadTimer = 0;
function maybePreloadPython() {
  if (pyPreloaded || activeRun || navigator.connection && navigator.connection.saveData) return;
  if (resolvedLanguage() !== "Python" || $("code").value.trim().length < 8) return;
  pyPreloaded = true;
  ensureRunner().then(() => { if (runner) runner.contentWindow.postMessage({ type: "preload", lang: "py" }, "*"); }).catch(() => { pyPreloaded = false; });
}
const schedulePreload = () => { clearTimeout(preloadTimer); preloadTimer = setTimeout(maybePreloadPython, 1200); };
$("code").addEventListener("input", schedulePreload);
$("language").addEventListener("change", schedulePreload);
async function runCode(opts) {
  if (activeRun) return;
  const replay = !!(opts && opts.replay);
  const code = $("code").value, name = resolvedLanguage(), rt = RUNTIME[name];
  $("consoleLang").textContent = name;
  if (!code.trim()) { addLine("info", "Nothing to run yet. Write some code first."); return; }
  if (rt === "html" || rt === "css") { showView("preview"); addLine("meta", name + " preview updated."); return; }
  if (!rt) { addLine("info", name + " can't run in the browser console. You can run JavaScript, TypeScript, Python, SQL and Lua, and preview HTML and CSS."); return; }
  if (replay) out.textContent = ""; else if (waitingInput) stdinLines = [];     // pressing Run again starts the program over
  waitingInput = false;
  setRunning(true);
  try { await ensureRunner(); } catch (err) { addLine("error", err.message); setRunning(false); return; }
  const id = ++runSeq; activeRun = { id, sent: stdinLines.length };
  addLine("meta", "Running " + name + "…");
  const fast = rt === "js" || rt === "ts" || rt === "lua";
  runner.contentWindow.postMessage({ type: "run", id, lang: rt, code, stdin: stdinLines.slice(), timeout: fast ? 5000 : 30000 }, "*");
  armWatchdog(id, rt === "js" ? 7000 : rt === "py" ? 45000 : 75000);
}
/* If the runner goes silent we stop it. While Python is downloading it tells us (phase "loading"), and we wait for as long as it takes. */
function armWatchdog(id, ms) {
  if (!activeRun || activeRun.id !== id) return;
  clearTimeout(activeRun.wd);
  activeRun.wd = setTimeout(() => { if (activeRun && activeRun.id === id) { destroyRunner(); addLine("error", "Stopped: the runner stopped responding."); activeRun = null; setRunning(false); } }, ms);
}
$("runBtn").addEventListener("click", () => runCode());
$("consoleForm").addEventListener("submit", e => {
  e.preventDefault();
  const box = $("consoleIn"), text = box.value.slice(0, 1000);
  if (stdinLines.length >= 200) { addLine("info", "That is enough input lines for one run. Press Run to start over."); return; }
  stdinLines.push(text); box.value = "";
  if (!activeRun && !waitingInput) { addLine("input", "› " + text); addLine("meta", "Saved. It is used the next time you press Run."); }
  else if (!activeRun) runCode({ replay: true });          // the program was waiting for this line
  else addLine("input", "› " + text);
  box.focus();
});
$("stopBtn").addEventListener("click", () => {
  if (!runner || !activeRun) return;
  const id = activeRun.id; runner.contentWindow.postMessage({ type: "stop" }, "*");
  setTimeout(() => { if (activeRun && activeRun.id === id) { destroyRunner(); addLine("error", "Stopped."); activeRun = null; setRunning(false); } }, 1500);
});
$("clearBtn").addEventListener("click", () => { out.textContent = ""; stdinLines = []; waitingInput = false; });
$("language").addEventListener("change", () => { $("consoleLang").textContent = resolvedLanguage(); });
document.addEventListener("keydown", e => { if ((e.ctrlKey || e.metaKey) && e.key === "Enter") { e.preventDefault(); runCode(); } });

updateCount(); scheduleHighlight();

/* ---------- your name and number (no login; kept by a session cookie) ---------- */
const nameDlg = $("nameDlg");
// Ranks are created by the developer on the website; the server sends their names and colors (/api/ranks). The server decides who has one; this only draws it.
let ranksMap = new Map(), ranksFull = new Map(), powerList = [], animLabels = {}, globalOff = new Set(), featureLabels = {}, lastPeers = [];
const roleOf = p => (p && !p.dev && p.role && ranksMap.has(p.role)) ? p.role : null;
// A rank's look. mode "solid": the one main color everywhere. mode "mix": a flowing rainbow like the developer's, made from the palette
// the developer picked, or (no palette) built automatically around the main color. CSS variables: --rc main color, --rg flowing gradient,
// --rcg the same colors for the spinning border, --rt readable text color on top of it, --rs speed. data-mode and data-anim pick the styles.
const SPEED_X = { slow: "1.7", normal: "1", fast: ".55" };
const hex2rgb = h => [1, 3, 5].map(i => parseInt(h.slice(i, i + 2), 16));
const rgb2hsl = ([r, g, b]) => { r /= 255; g /= 255; b /= 255; const mx = Math.max(r, g, b), mn = Math.min(r, g, b), l = (mx + mn) / 2; let h = 0, sat = 0; if (mx !== mn) { const d = mx - mn; sat = l > .5 ? d / (2 - mx - mn) : d / (mx + mn); h = mx === r ? (g - b) / d + (g < b ? 6 : 0) : mx === g ? (b - r) / d + 2 : (r - g) / d + 4; h *= 60; } return [h, sat * 100, l * 100]; };
const hsl2hex = (h, sat, l) => { sat /= 100; l /= 100; const k = n => (n + h / 30) % 12, a = sat * Math.min(l, 1 - l), f = n => l - a * Math.max(-1, Math.min(k(n) - 3, Math.min(9 - k(n), 1))); return "#" + [f(0), f(8), f(4)].map(x => Math.round(x * 255).toString(16).padStart(2, "0")).join(""); };
const lum = hex => { const [r, g, b] = hex2rgb(hex).map(v => { v /= 255; return v <= .03928 ? v / 12.92 : Math.pow((v + .055) / 1.055, 2.4); }); return .2126 * r + .7152 * g + .0722 * b; };
function autoSpectrum(color) {                                    // the main color first, then the rest of the rainbow around it
  const [h, sat, l] = rgb2hsl(hex2rgb(color)), s2 = Math.max(sat, 60), l2 = Math.min(80, Math.max(l, 62)), out = [color];
  for (let i = 1; i < 7; i++) out.push(hsl2hex((h + i * 360 / 7) % 360, s2, l2));
  return out;
}
function rankColors(r) {
  if (r.mode === "solid") return [r.color];
  const pal = r.palette || [];
  if (pal.length >= 2) return pal;
  if (pal.length === 1) return [r.color, pal[0]];
  return autoSpectrum(r.color);
}
function paintRank(el, r) {                                       // r: { color, palette, mode, anim, speed } (a saved rank, or a preview being edited)
  const cols = rankColors(r), solid = r.mode === "solid", mean = cols.reduce((t, c) => t + lum(c), 0) / cols.length;
  el.classList.add("rank"); el.style.setProperty("--rc", r.color);
  el.style.setProperty("--rg", "linear-gradient(100deg," + cols.concat(cols[0]).join(",") + ")");          // ends where it starts, so it flows without a seam
  el.style.setProperty("--rcg", cols.concat(cols[0]).join(","));
  el.style.setProperty("--rt", mean > .38 ? "#17171c" : "#ffffff");
  el.style.setProperty("--rs", SPEED_X[r.speed] || "1");
  el.dataset.mode = solid ? "solid" : "mix";
  if (r.anim && r.anim !== "none") el.dataset.anim = r.anim; else delete el.dataset.anim;
}
function applyRank(el, role) {
  const r = role ? ranksFull.get(role) : null;
  if (!r) { el.classList.remove("rank"); for (const k of ["--rc", "--rg", "--rcg", "--rt", "--rs"]) el.style.removeProperty(k); delete el.dataset.anim; delete el.dataset.mode; return; }
  paintRank(el, r);
}
function rankTag(role, fixed) {
  const t = document.createElement("span"); t.className = "ptag rank-tag";
  const star = document.createElement("i"); star.className = "rk-star"; star.setAttribute("aria-hidden", "true"); star.textContent = "✦";
  t.append(star, role); if (fixed) paintRank(t, fixed); else applyRank(t, role); return t;
}
// Powers: the server decides; this only decides what to show. Developers hold every power.
const rankPowersOf = role => { const r = role ? ranksFull.get(role) : null; return r ? r.powers || [] : []; };
const can = key => Boolean(curUser) && (Boolean(curUser.dev) || rankPowersOf(curUser.role).includes(key));
const PANEL_POWERS = ["find_users", "assign_rank", "rename_users", "ban_users", "limit_users", "limit_everyone", "notify_users"];
const hasPanel = () => Boolean(curUser) && (curUser.dev || PANEL_POWERS.some(can));
function showUser(u) {
  curUser = u; const c = $("userChip"), role = roleOf(u); c.textContent = "";
  c.classList.toggle("dev", Boolean(u.dev)); applyRank(c, role);
  const b = document.createElement("b"); b.textContent = u.name; if (u.dev) b.className = "rainbow"; else applyRank(b, role);
  c.append(b, " · #" + u.id);
  if (u.dev) { const t = document.createElement("span"); t.className = "ptag dev-tag"; t.textContent = "developer"; c.append(t); }
  else if (role) c.append(rankTag(role));
  c.classList.remove("hidden");
  $("rolesBtn").classList.toggle("hidden", !hasPanel());
  if (typeof onUserShown === "function") onUserShown(u);
  $("rolesBtn").querySelector(".label").textContent = u.dev ? "Developer panel" : "Staff panel";
  $("maintBtn").classList.toggle("hidden", !u.dev);
  applyFeatureLimits();
  if (typeof applyPermissions === "function") applyPermissions();
  refreshMyStats();
  updateAuthUi();
  $("settingsBtn").classList.remove("hidden");
  if (typeof applyMaintenance === "function") applyMaintenance(maint);
}
function openNameDialog() { if (!nameDlg.open) { nameMsg("", ""); $("nameSave").disabled = false; nameDlg.showModal(); $("nameInput").focus(); } }
nameDlg.addEventListener("cancel", e => e.preventDefault());   // a name is required
let nameTimer = 0, nameOk = false, nameSeq = 0;
function nameMsg(text, kind) {
  const e = $("nameErr"); e.textContent = text; e.classList.toggle("hidden", !text); e.classList.toggle("ok", kind === "ok");
  $("nameInput").classList.toggle("bad", kind === "bad"); $("nameInput").classList.toggle("good", kind === "ok");
}
$("nameInput").addEventListener("input", () => {            // tells you while you type if the name is free
  clearTimeout(nameTimer); nameOk = false; $("nameSave").disabled = true;
  const name = $("nameInput").value.trim().replace(/\s+/g, " ");
  if (!name) { nameMsg("", ""); return; }
  const seq = ++nameSeq;
  nameTimer = setTimeout(async () => {
    try {
      const r = await fetch("/api/name-available?name=" + encodeURIComponent(name)), d = await r.json().catch(() => ({}));
      if (seq !== nameSeq) return;
      if (!r.ok || typeof d.available !== "boolean") { nameOk = true; $("nameSave").disabled = false; nameMsg("Couldn't check this name right now. It will be checked when you continue.", ""); return; }   // never say "taken" unless the server said so
      nameOk = Boolean(d.available); $("nameSave").disabled = !nameOk;
      nameMsg(d.available ? "\u2713 \"" + name + "\" is available" : "That name is already taken. Please choose another.", d.available ? "ok" : "bad");
    } catch { nameOk = true; $("nameSave").disabled = false; nameMsg("", ""); }   // server decides on save
  }, 300);
});
async function saveName() {
  const name = $("nameInput").value.trim(), err = $("nameErr");
  if (!name) { nameMsg("Please enter a name.", "bad"); return; }
  if ($("nameInput").classList.contains("bad")) return;
  $("nameSave").disabled = true;
  try {
    const r = await fetch("/api/me", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ name }) });
    const d = await r.json();
    if (!r.ok) { if (d.taken) nameOk = false; throw new Error(d.error || "Could not save your name."); }
    showUser(d.user); nameDlg.close();
    socket.disconnect(); socket.connect();            // reconnect so the server sees your new session
  } catch (e) { nameMsg(e.message, "bad"); }
  finally { $("nameSave").disabled = !nameOk && $("nameInput").classList.contains("bad"); }
}
$("nameSave").addEventListener("click", saveName);
$("nameInput").addEventListener("keydown", e => { if (e.key === "Enter") saveName(); });
socket.on("need-user", askWho);
Promise.all([
  fetch("/api/me").then(r => r.json()),
  fetch("/api/auth/providers").then(r => r.json()).catch(() => ({ providers: [] }))
]).then(([d, a]) => {
  loginProviders = (a && a.providers) || [];
  if (d.user) { showUser(d.user); if (loginFlag === "ok") celebrate(d.user.name); }
  else {
    updateAuthUi();
    const t = setInterval(() => {
      if (!document.body.classList.contains("ready")) return;
      clearInterval(t);
      if (curUser) return;
      if (loginProviders.length && !guestChosen()) showLoginPage("start", loginFlag === "failed" ? "That sign-in did not work. Please try again, or continue as a guest." : loginFlag === "off" ? "Sign-in is not set up on this site yet." : "");
      else openNameDialog();
    }, 250);
  }
  if (loginFlag === "failed" && d.user) showNotice("That sign-in did not work. Please try again.", "bad");
}).catch(() => {});
/* ---------- who's here ---------- */
const peerRows = new Map();
function renderPeers(peers) {
  lastPeers = peers;
  const list = $("peerList"), byUser = new Map();
  for (const p of peers || []) { const k = String(p.uid ?? p.pid), e = byUser.get(k); if (e) e.n++; else byUser.set(k, { ...p, n: 1 }); }
  $("peerCount").textContent = byUser.size;
  list.querySelector(".peer-empty")?.remove();
  for (const [k, li] of peerRows) if (!byUser.has(k)) {                     // someone left
    peerRows.delete(k); li.classList.add("leaving"); setTimeout(() => li.remove(), reduceMotion ? 0 : 220);
  }
  for (const [k, p] of byUser) {
    let li = peerRows.get(k);
    if (!li) {
      li = document.createElement("li"); li.className = "peer enter";
      li.innerHTML = '<span class="pdot"></span><span class="pbody"><span class="pname"></span><span class="pmeta"></span></span><span class="ptags"></span>';
      peerRows.set(k, li); list.appendChild(li);
    }
    li.querySelector(".pdot").style.setProperty("--c", /^#[0-9a-f]{6}$/i.test(p.color) ? p.color : "#9a9aa3");
    const role = roleOf(p), pn = li.querySelector(".pname");
    li.classList.toggle("dev", Boolean(p.dev)); pn.textContent = p.name; pn.classList.toggle("rainbow", Boolean(p.dev));
    applyRank(li, role); if (!p.dev) applyRank(pn, role); else pn.classList.remove("rank");
    li.querySelector(".pmeta").textContent = "#" + p.uid + (p.n > 1 ? " · " + p.n + " tabs" : "");
    const tags = li.querySelector(".ptags"); tags.textContent = "";
    const tag = (t, cls) => { const s = document.createElement("span"); s.className = "ptag" + (cls ? " " + cls : ""); s.textContent = t; tags.appendChild(s); };
    if (p.dev) tag("developer", "dev-tag"); else if (role) tags.appendChild(rankTag(role));
    if (curUser && p.uid === curUser.id) tag("you");
    if (p.owner) tag("owner");
  }
  const av = $("avatars"); av.textContent = "";
  [...byUser.values()].slice(0, 5).forEach(p => {
    const s = document.createElement("span"); s.className = "av" + (p.dev ? " dev" : ""); if (!p.dev) applyRank(s, roleOf(p)); s.textContent = (p.name || "?").trim().charAt(0).toUpperCase();
    s.style.setProperty("--c", /^#[0-9a-f]{6}$/i.test(p.color) ? p.color : "#9a9aa3"); s.title = p.name + " (#" + p.uid + ")" + (curUser && p.uid === curUser.id ? " - you" : "");
    av.appendChild(s);
  });
  if (byUser.size > 5) { const s = document.createElement("span"); s.className = "av more"; s.textContent = "+" + (byUser.size - 5); av.appendChild(s); }
  if (!byUser.size && !list.querySelector(".peer-empty")) {
    const li = document.createElement("li"); li.className = "peer-empty";
    li.textContent = roomId ? "Connecting…" : "Open or create a workspace to see who is connected.";
    list.appendChild(li);
  }
}

/* ---------- features switched off by the developer (the server enforces create / edit / chat / feedback; the rest are hidden or disabled here) ---------- */
let featureStates = {};                                            // for everyone but developers: feature -> "off" | "soon" | "removed" (a feature that is on has no entry)
function featureStateOf(f) {
  if (curUser && (curUser.dev || can("bypass_features"))) return "on";
  if (featureStates[f]) return featureStates[f];
  return curUser && (curUser.off || []).includes(f) ? "off" : "on";
}
function featureIsOff(f) { return featureStateOf(f) !== "on"; }
const FEATURE_UI = { create: ["createRoom", "newRoom"], run: ["runBtn"], preview: ["viewPreview"], copy: ["copyCode"], feedback: ["feedbackBtn"], phonk: ["phonkBtn"], messages: [] };
function applyFeatureLimits() {
  for (const [f, ids] of Object.entries(FEATURE_UI)) for (const id of ids) {
    const el = $(id); if (!el) continue; const st = featureStateOf(f);
    el.classList.toggle("feat-hide", st === "removed");              // removed: gone from the page
    el.classList.toggle("feat-off", st !== "on" && st !== "removed"); // off or soon: shown but can't be used
    el.setAttribute("aria-disabled", st === "on" ? "false" : "true");
    if (st === "soon" || st === "off") el.dataset.featState = st; else delete el.dataset.featState;
    if (st !== "on") { if (!("offTitle" in el.dataset)) el.dataset.offTitle = el.title || ""; el.title = st === "soon" ? "Coming soon" : "Turned off by the developer"; } else if ("offTitle" in el.dataset) { el.title = el.dataset.offTitle; delete el.dataset.offTitle; }
  }
  $("phonkBubble").classList.toggle("feat-hide", featureIsOff("phonk"));
  const chatOff = featureIsOff("chat"); $("chatFab").classList.toggle("feat-hide", chatOff); if (chatOff) chatSetOpen(false);
  const ed = $("code"); if (featureIsOff("edit")) ed.readOnly = true;
  paintMsgBox();
}
document.addEventListener("click", e => {          // a switched-off control does nothing, whatever other code is listening
  const el = e.target.closest && e.target.closest(".feat-off"); if (!el) return;
  e.preventDefault(); e.stopImmediatePropagation(); showNotice(el.dataset.featState === "soon" ? "This is coming soon." : "The developer has turned this off for you.", "bad");
}, true);
document.addEventListener("keydown", e => { if ((e.ctrlKey || e.metaKey) && e.key === "Enter" && featureIsOff("run")) { e.preventDefault(); e.stopImmediatePropagation(); showNotice("Running code is turned off for you.", "bad"); } }, true);
function setRanks(d) {
  if (!d) return;
  ranksMap = new Map((d.ranks || []).map(r => [r.name, r.color])); ranksFull = new Map((d.ranks || []).map(r => [r.name, r]));
  powerList = d.powers || powerList; animLabels = d.anims || animLabels;
  globalOff = new Set(d.globalOff || []); featureStates = d.featureStates || {}; featureLabels = d.features || featureLabels;
  if (d.updates) { updatesState = d.updates; applyUpdates(); }
  if (curUser) showUser(curUser); else applyFeatureLimits();
  renderPeers(lastPeers);
  if (rolesDlg.open) { fitPanelTabs(); renderRankList(); renderPowerList(); renderFeatureList(); }
}
socket.on("ranks-updated", setRanks);
socket.on("banned", () => location.reload());                         // the server then shows the "banned" page
socket.on("connect_error", e => { if (e && e.message === "banned") location.reload(); });
fetch("/api/ranks", { cache: "no-store" }).then(r => r.ok ? r.json() : null).then(setRanks).catch(() => {});
socket.on("me-updated", d => { if (d && d.user && curUser && d.user.id === curUser.id) { showUser({ ...curUser, ...d.user, name: d.user.name || curUser.name }); if (rolesDlg.open) fitPanelTabs(); } });

/* ---------- developer panel (the button is only shown to developers; the server checks every request) ---------- */
const rolesDlg = $("rolesDlg"), rolesList = $("rolesList"), rolesMsg = $("rolesMsg");
let rolesTimer = 0, rolesSeq = 0;
function rolesNote(text, kind) { rolesMsg.textContent = text || ""; rolesMsg.className = "roles-msg" + (kind ? " " + kind : ""); }
function savedNote(d, text) { if (d && d.saved === false) rolesNote(text + " (not saved to the database yet: run supabase/schema.sql, or it resets on restart)", "bad"); else rolesNote(text, "ok"); }
async function devPost(url, body) {
  const r = await fetch(url, { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(body) });
  const d = await r.json().catch(() => ({})); if (!r.ok) throw new Error(d.error || "That didn't work."); return d;
}
const mk = (tag, cls, text) => { const e = document.createElement(tag); if (cls) e.className = cls; if (text != null) e.textContent = text; return e; };
function featChips(wrap, offList, onToggle) {
  wrap.textContent = "";
  for (const [f, label] of Object.entries(featureLabels)) {
    const off = offList.has(f), b = mk("button", "fchip" + (off ? " off" : ""), label); b.type = "button"; b.setAttribute("aria-pressed", off ? "true" : "false");
    b.title = off ? "Turned off. Click to turn on." : "On. Click to turn off.";
    b.addEventListener("click", async () => { b.disabled = true; try { await onToggle(f, !off); } catch (e) { rolesNote(e.message, "bad"); } b.disabled = false; });
    wrap.append(b);
  }
}
function userCard(u) {
  const li = mk("li", "dcard"), top = mk("div", "dc-top"), nm = mk("span", "rname", u.name); if (u.dev) nm.classList.add("rainbow");
  const idn = mk("small", "", "#" + u.id); nm.append(idn); top.append(nm);
  const stats = u.stats ? mk("small", "dc-stats", (u.stats.created != null ? u.stats.created + " created" : "") + (u.stats.saved != null ? " · " + u.stats.saved + " saved" : "")) : null;
  if (u.dev) { top.append(mk("span", "ptag dev-tag", "developer")); li.append(top); if (stats) li.append(stats); li.append(mk("p", "dc-note", "Developer accounts can't be changed by anyone else.")); return li; }
  const state = mk("span", "dc-state"), paint = () => { state.textContent = ""; if (u.banned) state.append(mk("span", "ptag ban-tag", "banned")); if (u.role && ranksMap.has(u.role)) state.append(rankTag(u.role)); };
  top.append(state); paint(); li.append(top); if (stats) li.append(stats);
  if (u.id === curUser.id && !curUser.dev) { li.append(mk("p", "dc-note", "That's you. You can't use staff powers on yourself.")); return li; }
  let shown = 0;
  // rank (needs "Give and remove ranks"; you can only hand out ranks whose powers you hold too)
  if (can("assign_rank")) {
    shown++;
    const rr = mk("div", "dc-row"), sel = document.createElement("select"); sel.setAttribute("aria-label", "Rank for " + u.name);
    const mayGive = n => curUser.dev || rankPowersOf(n).every(pw => rankPowersOf(curUser.role).includes(pw));
    const fill = () => { sel.textContent = ""; sel.append(new Option("No rank", "")); for (const n of ranksMap.keys()) { if (!mayGive(n) && n !== u.role) continue; const o = new Option(n, n); o.disabled = !mayGive(n); sel.append(o); } sel.value = u.role && ranksMap.has(u.role) ? u.role : ""; };
    fill(); rr.append(mk("label", "dc-lbl", "Rank"), sel);
    sel.addEventListener("change", async () => { sel.disabled = true; rolesNote("Saving…"); try { const d = await devPost("/api/roles", { userNumber: u.id, role: sel.value || null }); u.role = d.user.role; paint(); rolesNote(u.name + " is now " + (u.role || "a regular user") + ".", "ok"); } catch (e) { fill(); rolesNote(e.message, "bad"); } sel.disabled = false; });
    li.append(rr);
  }
  // rename
  if (can("rename_users")) {
    shown++;
    const rn = mk("div", "dc-row"), ni = document.createElement("input"); ni.maxLength = 24; ni.placeholder = "New name"; ni.setAttribute("aria-label", "New name for " + u.name);
    const nb = mk("button", "", "Rename"); nb.type = "button"; rn.append(mk("label", "dc-lbl", "Name"), ni, nb);
    nb.addEventListener("click", async () => { if (!ni.value.trim()) return; nb.disabled = true; try { const d = await devPost("/api/dev/rename", { userNumber: u.id, name: ni.value }); u.name = d.user.name; nm.firstChild.textContent = u.name; ni.value = ""; rolesNote("Renamed to " + u.name + ".", "ok"); } catch (e) { rolesNote(e.message, "bad"); } nb.disabled = false; });
    ni.addEventListener("keydown", e => { if (e.key === "Enter") nb.click(); });
    li.append(rn);
  }
  // notify just this person (one button)
  if (can("notify_users")) {
    shown++;
    const nr = mk("div", "dc-row"), ni2 = document.createElement("input"); ni2.maxLength = 500; ni2.placeholder = "Notification for " + u.name + " only"; ni2.setAttribute("aria-label", "Notification for " + u.name);
    const nb2 = mk("button", "primary", "Notify"); nb2.type = "button"; nr.append(mk("label", "dc-lbl", "Notify"), ni2, nb2);
    nb2.addEventListener("click", async () => { if (!ni2.value.trim()) return; nb2.disabled = true; try { const d = await devPost("/api/dev/notify", { userNumber: u.id, text: ni2.value }); ni2.value = ""; rolesNote("Sent to " + u.name + (d.delivered ? " (they are online now)." : ". They will see it when they come back."), "ok"); } catch (e) { rolesNote(e.message, "bad"); } nb2.disabled = false; });
    ni2.addEventListener("keydown", e => { if (e.key === "Enter") nb2.click(); });
    li.append(nr);
  }
  // ban
  if (can("ban_users")) {
    shown++;
    const bn = mk("div", "dc-row"), ri = document.createElement("input"); ri.maxLength = 200; ri.placeholder = "Reason (shown to them)"; ri.setAttribute("aria-label", "Ban reason");
    const bb = mk("button", "danger-btn"); bn.append(mk("label", "dc-lbl", "Ban"), ri, bb);
    const paintBan = () => { bb.textContent = u.banned ? "Unban" : "Ban"; ri.classList.toggle("hidden", Boolean(u.banned)); bb.classList.toggle("danger-btn", !u.banned); }; paintBan();
    bb.addEventListener("click", async () => { bb.disabled = true; try { const d = await devPost("/api/dev/ban", { userNumber: u.id, banned: !u.banned, reason: ri.value }); u.banned = d.user.banned; ri.value = ""; paintBan(); paint(); savedNote(d, u.name + (u.banned ? " is banned and was disconnected." : " is no longer banned.")); } catch (e) { rolesNote(e.message, "bad"); } bb.disabled = false; });
    li.append(bn);
  }
  // features, for this person only
  if (can("limit_users")) {
    shown++;
    const fw = mk("div", "dc-feats"); li.append(mk("div", "dc-lbl block", "Features (click to turn off for this person)"), fw);
    const offSet = () => new Set(u.off || []);
    const draw = () => featChips(fw, offSet(), async (f, off) => { const d = await devPost("/api/dev/features", { userNumber: u.id, feature: f, off }); u.off = d.user.off; draw(); savedNote(d, (off ? "Turned off " : "Turned on ") + (featureLabels[f] || f) + " for " + u.name + "."); });
    draw();
  }
  if (!shown) li.append(mk("p", "dc-note", "Your rank lets you look people up, but not change them."));
  return li;
}
async function rolesSearch() {
  const q = $("rolesQ").value.trim(), seq = ++rolesSeq;
  if (!q) { rolesTop(); return; }
  try {
    const r = await fetch("/api/roles?q=" + encodeURIComponent(q));
    if (!r.ok) throw new Error("Could not search.");
    const d = await r.json(); if (seq !== rolesSeq) return;
    rolesList.textContent = ""; (d.users || []).forEach(u => rolesList.append(userCard(u)));
    rolesNote(d.users && d.users.length ? "" : "No one found.");
  } catch (e) { if (seq === rolesSeq) rolesNote(e.message, "bad"); }
}
async function rolesTop() {
  const seq = ++rolesSeq; rolesList.textContent = ""; rolesNote("");
  try {
    const r = await fetch("/api/roles/top", { cache: "no-store" }); if (!r.ok) return;
    const d = await r.json(); if (seq !== rolesSeq || $("rolesQ").value.trim()) return;
    (d.users || []).forEach(u => rolesList.append(userCard(u)));
    if (d.users && d.users.length) rolesNote("Most workspaces created. Type a name or number to find anyone.");
  } catch {}
}
const MAX_PALETTE = 5;
const isDevUser = () => Boolean(curUser && curUser.dev);
function armedDelete(btn, label, run) {                              // first click arms it, a second click within 3.5 seconds does it
  let armed = 0;
  btn.addEventListener("click", async () => {
    if (!armed) { armed = setTimeout(() => { armed = 0; btn.textContent = label; }, 3500); btn.textContent = "Click again to delete"; return; }
    clearTimeout(armed); btn.disabled = true;
    try { await run(); } catch (e) { rolesNote(e.message, "bad"); btn.disabled = false; btn.textContent = label; armed = 0; }
  });
}
function rankCard(rank) {
  const name = rank.name, li = mk("li", "dcard rank-card");
  const draft = { color: rank.color, palette: [...(rank.palette || [])], mode: rank.mode === "solid" ? "solid" : "mix", anim: rank.anim || "none", speed: rank.speed || "normal" };   // edited live in the preview, saved when you let go
  // header: a live preview that looks exactly like the chip people will see (border, name, number, tag), and delete
  const head = mk("div", "dc-top"), chip = mk("span", "user-chip rk-chip"), prevName = mk("b", "", name), prevTag = rankTag(name, draft), del = mk("button", "danger-btn", "Delete"); del.type = "button"; del.dataset.fid = name + ":del";
  chip.append(prevName, " \u00b7 #7", prevTag);
  const paintPrev = () => { paintRank(chip, draft); paintRank(prevName, draft); paintRank(prevTag, draft); }; paintPrev();
  head.append(chip, mk("span", "rk-grow"), del); li.append(head);
  armedDelete(del, "Delete", async () => { const d = await devPost("/api/dev/ranks/delete", { name }); setRanks(d); savedNote(d, "Deleted the " + name + " rank. Everyone who had it lost it."); });
  const save = async () => {
    try { const d = await devPost("/api/dev/ranks/style", { name, color: draft.color, palette: draft.palette, mode: draft.mode, anim: draft.anim, speed: draft.speed }); setRanks(d); savedNote(d, "Saved the look of " + name + "."); }
    catch (e) { rolesNote(e.message, "bad"); }
  };
  // style: color only, or a mix (the flowing rainbow the developer has)
  const mr = mk("div", "dc-row"), seg = mk("div", "rk-seg"); seg.setAttribute("role", "group"); seg.setAttribute("aria-label", "Look of " + name);
  const segBtns = [["solid", "Color only"], ["mix", "Mix"]].map(([k, l]) => { const b = mk("button", "", l); b.type = "button"; b.dataset.fid = name + ":mode:" + k; b.addEventListener("click", () => { if (draft.mode === k) return; draft.mode = k; syncMode(); paintPrev(); save(); }); seg.append(b); return [k, b]; });
  mr.append(mk("label", "dc-lbl", "Style"), seg); li.append(mr);
  // color
  const cr = mk("div", "dc-row"), col = document.createElement("input"); col.type = "color"; col.value = draft.color; col.className = "rk-color"; col.dataset.fid = name + ":color"; col.setAttribute("aria-label", "Main color of " + name);
  col.addEventListener("input", () => { draft.color = col.value; paintPrev(); }); col.addEventListener("change", save);
  const colNote = mk("small", "dc-stats"); cr.append(mk("label", "dc-lbl", "Color"), col, colNote); li.append(cr);
  // palette (Mix only): up to five colors that flow into each other; leave it empty and the rainbow is built around the main color
  const pr = mk("div", "dc-row rk-palrow"), pal = mk("div", "rk-pal"); pr.append(mk("label", "dc-lbl", "Mix"), pal); li.append(pr);
  const syncMode = () => {
    segBtns.forEach(([k, b]) => { b.classList.toggle("on", draft.mode === k); b.setAttribute("aria-pressed", String(draft.mode === k)); });
    pr.classList.toggle("hidden", draft.mode !== "mix");
    colNote.textContent = draft.mode === "mix" ? "The mix starts from this color." : "Border, name and tag all use this one color.";
  };
  const drawPal = () => {
    pal.textContent = "";
    draft.palette.forEach((c, i) => {
      const sw = mk("span", "rk-sw"), inp = document.createElement("input"); inp.type = "color"; inp.value = c; inp.setAttribute("aria-label", "Palette color " + (i + 1) + " of " + name); inp.dataset.fid = name + ":pal" + i;
      inp.addEventListener("input", () => { draft.palette[i] = inp.value; paintPrev(); }); inp.addEventListener("change", save);
      const x = mk("button", "rk-x", "×"); x.type = "button"; x.setAttribute("aria-label", "Remove palette color " + (i + 1));
      x.addEventListener("click", () => { draft.palette.splice(i, 1); drawPal(); paintPrev(); save(); });
      sw.append(inp, x); pal.append(sw);
    });
    if (!draft.palette.length) pal.append(mk("small", "dc-stats", "Automatic rainbow from the main color."));
    if (draft.palette.length < MAX_PALETTE) {
      const add = mk("button", "rk-add", draft.palette.length ? "+ Color" : "+ Pick my own colors"); add.type = "button"; add.dataset.fid = name + ":addpal";
      add.addEventListener("click", () => { draft.palette.push(draft.palette.length ? draft.palette[draft.palette.length - 1] : draft.color); drawPal(); paintPrev(); save(); });
      pal.append(add);
    }
  };
  drawPal(); syncMode();
  // animation and speed
  const ar = mk("div", "dc-row"), an = document.createElement("select"), sp = document.createElement("select");
  an.setAttribute("aria-label", "Animation for " + name); an.dataset.fid = name + ":anim"; sp.setAttribute("aria-label", "Animation speed for " + name); sp.dataset.fid = name + ":speed";
  for (const [k, l] of Object.entries(animLabels)) an.append(new Option(l, k)); an.value = draft.anim in animLabels ? draft.anim : "none";
  for (const k of ["slow", "normal", "fast"]) sp.append(new Option(k[0].toUpperCase() + k.slice(1), k)); sp.value = draft.speed;
  an.addEventListener("change", () => { draft.anim = an.value; paintPrev(); save(); }); sp.addEventListener("change", () => { draft.speed = sp.value; paintPrev(); save(); });
  ar.append(mk("label", "dc-lbl", "Effect"), an, sp); li.append(ar);
  li.append(mk("p", "dc-note", "Effects are extra on top of the style. Fire, Frost, Neon and Shimmer replace the flowing name color; Blood dripping, Glow, Glitch and Sparkle sit on top of it. Speed also changes how fast the border and colors move."));
  // powers: click to switch each one on or off
  const have = new Set(rank.powers || []), keys = powerList.map(x => x.key);
  const pbar = mk("div", "dc-row rk-pbar"), all = mk("button", "", "All"), none = mk("button", "", "None"); all.type = none.type = "button";
  all.dataset.fid = name + ":all"; none.dataset.fid = name + ":none";
  const setAll = async (list, msg) => { try { const d = await devPost("/api/dev/ranks/powers", { name, powers: list }); setRanks(d); savedNote(d, msg); } catch (e) { rolesNote(e.message, "bad"); } };
  all.addEventListener("click", () => setAll(keys, name + " now holds every power.")); none.addEventListener("click", () => setAll([], name + " holds no powers now."));
  pbar.append(mk("span", "dc-lbl block rk-ptitle", "Powers: " + keys.filter(k => have.has(k)).length + " of " + keys.length + " on (click to switch)"), all, none); li.append(pbar);
  const groups = []; for (const x of powerList) { let g = groups.find(y => y.name === x.group); if (!g) groups.push(g = { name: x.group, list: [] }); g.list.push(x); }
  for (const g of groups) {
    const wrap = mk("div", "dc-feats"); li.append(mk("div", "rk-pg", g.name), wrap);
    for (const x of g.list) {
      const on = have.has(x.key), b = mk("button", "pchip" + (on ? " on" : ""), x.label); b.type = "button"; b.setAttribute("aria-pressed", on ? "true" : "false"); b.title = x.desc; b.dataset.fid = name + ":p:" + x.key;
      b.addEventListener("click", async () => { b.disabled = true; try { const d = await devPost("/api/dev/ranks/powers", { name, power: x.key, on: !on }); setRanks(d); savedNote(d, (on ? "Took the power “" : "Gave the power “") + x.label + (on ? "” away from " : "” to ") + name + "."); } catch (e) { rolesNote(e.message, "bad"); b.disabled = false; } });
      wrap.append(b);
    }
  }
  return li;
}
function renderRankList() {
  if (!isDevUser()) return;
  const ul = $("rankList"), keep = document.activeElement && ul.contains(document.activeElement) ? document.activeElement.dataset.fid : null;
  ul.textContent = "";
  if (!ranksFull.size) { ul.append(mk("li", "dc-empty", "No ranks yet. Create one above.")); return; }
  for (const r of ranksFull.values()) ul.append(rankCard(r));
  if (keep) { const el = [...ul.querySelectorAll("[data-fid]")].find(e => e.dataset.fid === keep); if (el) el.focus(); }
}
function renderPowerList() {
  if (!isDevUser()) return;
  const ul = $("powerList"); ul.textContent = "";
  for (const x of powerList) {
    const holders = [...ranksFull.values()].filter(r => (r.powers || []).includes(x.key)).map(r => r.name);
    const li = mk("li", "dcard rank-row pw-row"), info = mk("div", "pw-info"), top = mk("div", "pw-top");
    top.append(mk("b", "", x.label), mk("span", "ptag" + (x.custom ? " rank-tag" : ""), x.group));
    info.append(top, mk("p", "dc-note", x.desc), mk("small", "dc-stats", holders.length ? "Held by: " + holders.join(", ") : "No rank holds this yet."));
    li.append(info);
    if (x.custom) { const del = mk("button", "danger-btn", "Delete"); del.type = "button"; armedDelete(del, "Delete", async () => { const d = await devPost("/api/dev/powers/delete", { key: x.key }); setRanks(d); savedNote(d, "Deleted the power “" + x.label + "”. Every rank lost it."); }); li.append(del); }
    ul.append(li);
  }
}
// The panel is for the developer (everything) and for ranks with panel powers (only the tabs their powers allow).
const TAB_NEEDS = { users: () => can("find_users"), ranks: isDevUser, powers: isDevUser, features: () => can("limit_everyone") || isDevUser(), notify: () => can("notify_users"), inbox: isDevUser, bans: () => can("ban_users") };
const visibleTabs = () => Object.keys(TAB_NEEDS).filter(t => TAB_NEEDS[t]());
function fitPanelTabs() {
  const vis = visibleTabs(), dev = isDevUser();
  rolesDlg.querySelectorAll("[data-dtab]").forEach(b => b.classList.toggle("hidden", !vis.includes(b.dataset.dtab)));
  $("panelTitle").textContent = dev ? "Developer panel" : "Staff panel";
  $("panelLead").textContent = dev ? "Only developers see this. Every action is checked on the server." : "What you can do here depends on the powers your rank holds. Every action is checked on the server.";
  if (!rolesDlg.open) return;
  const cur = rolesDlg.querySelector('[data-dtab][aria-selected="true"]');
  if (!vis.length) rolesDlg.close(); else if (!cur || !vis.includes(cur.dataset.dtab)) devTab(vis[0]);
}
const FEATURE_STATE_LABELS = [["on", "On"], ["off", "Off"], ["soon", "Soon"], ["removed", "Removed"]];
function renderFeatureList() {
  const wrap = $("featList"); wrap.textContent = "";
  for (const [f, label] of Object.entries(featureLabels)) {
    const cur = featureStates[f] || "on", row = mk("div", "feat-row"), seg = mk("div", "rk-seg"); seg.setAttribute("role", "group"); seg.setAttribute("aria-label", label);
    row.append(mk("span", "feat-name", label));
    for (const [k, l] of FEATURE_STATE_LABELS) {
      const b = mk("button", (cur === k ? "on " : "") + "st-" + k, l); b.type = "button"; b.setAttribute("aria-pressed", String(cur === k)); b.dataset.fid = f + ":" + k;
      b.addEventListener("click", async () => {
        if (cur === k) return; b.disabled = true;
        try { const d = await devPost("/api/dev/features", { feature: f, state: k }); setRanks(d); savedNote(d, k === "on" ? label + " is on for everyone again." : k === "removed" ? label + " is removed from the page for everyone except developers. Set it to On to bring it back." : k === "soon" ? label + " now shows as Soon." : label + " is turned off for everyone except developers."); }
        catch (e) { rolesNote(e.message, "bad"); b.disabled = false; }
      });
      seg.append(b);
    }
    row.append(seg); wrap.append(row);
  }
  renderUpdatesCard();
}
async function renderBanList() {
  const ul = $("banList"); ul.textContent = ""; ul.append(mk("li", "dc-empty", "Loading…"));
  try {
    const r = await fetch("/api/dev/overview", { cache: "no-store" }); if (!r.ok) throw new Error("Could not load bans."); const d = await r.json(); ul.textContent = "";
    if (!d.banned.length) { ul.append(mk("li", "dc-empty", "Nobody is banned.")); return; }
    for (const b of d.banned) {
      const li = mk("li", "dcard rank-row"), nm = mk("span", "rname", b.name); nm.append(mk("small", "", "#" + b.id + (b.reason ? " · " + b.reason : ""))); const ub = mk("button", "", "Unban"); ub.type = "button";
      ub.addEventListener("click", async () => { ub.disabled = true; try { const x = await devPost("/api/dev/ban", { userNumber: b.id, banned: false }); savedNote(x, b.name + " is no longer banned."); li.remove(); if (!ul.children.length) ul.append(mk("li", "dc-empty", "Nobody is banned.")); } catch (e) { rolesNote(e.message, "bad"); ub.disabled = false; } });
      li.append(nm, ub); ul.append(li);
    }
  } catch (e) { ul.textContent = ""; rolesNote(e.message, "bad"); }
}
function devTab(name) {
  rolesDlg.querySelectorAll("[data-dtab]").forEach(b => b.setAttribute("aria-selected", b.dataset.dtab === name ? "true" : "false"));
  rolesDlg.querySelectorAll("[data-dpane]").forEach(p => p.classList.toggle("hidden", p.dataset.dpane !== name));
  rolesNote("");
  if (name === "users") { $("rolesQ").focus(); rolesSearch(); } else if (name === "ranks") renderRankList(); else if (name === "powers") renderPowerList(); else if (name === "features") renderFeatureList(); else if (name === "notify") renderNotifySent(); else if (name === "inbox") renderInbox(); else if (name === "bans") renderBanList();
}
rolesDlg.querySelectorAll("[data-dtab]").forEach(b => b.addEventListener("click", () => devTab(b.dataset.dtab)));
$("rankAdd").addEventListener("click", async () => {
  const name = $("rankName").value.trim(); if (!name) { rolesNote("Give the rank a name.", "bad"); return; }
  $("rankAdd").disabled = true;
  try { const d = await devPost("/api/dev/ranks", { name, color: $("rankColor").value, mode: $("rankMode").value }); $("rankName").value = ""; setRanks(d); savedNote(d, "Created the " + name + " rank."); } catch (e) { rolesNote(e.message, "bad"); }
  $("rankAdd").disabled = false;
});
$("rankName").addEventListener("keydown", e => { if (e.key === "Enter") $("rankAdd").click(); });
$("powerAdd").addEventListener("click", async () => {
  const label = $("powerName").value.trim(); if (!label) { rolesNote("Name the power.", "bad"); return; }
  $("powerAdd").disabled = true;
  try { const d = await devPost("/api/dev/powers", { label }); $("powerName").value = ""; setRanks(d); savedNote(d, "Added the power \u201c" + label + "\u201d. Switch it on for a rank in the Ranks tab."); } catch (e) { rolesNote(e.message, "bad"); }
  $("powerAdd").disabled = false;
});
$("powerName").addEventListener("keydown", e => { if (e.key === "Enter") $("powerAdd").click(); });
$("rolesBtn").addEventListener("click", () => { fitPanelTabs(); const vis = visibleTabs(); if (!vis.length) return; $("rolesQ").value = ""; rolesDlg.showModal(); devTab(vis[0]); });
$("rolesQ").addEventListener("input", () => { clearTimeout(rolesTimer); rolesTimer = setTimeout(rolesSearch, 300); });
$("rolesClose").addEventListener("click", () => rolesDlg.close());

/* ---------- settings pop-up (account, saved workspaces, appearance, limits) ---------- */
const settingsDlg = $("settingsDlg"), setTabs = [...settingsDlg.querySelectorAll(".set-tab")], setPanels = [...settingsDlg.querySelectorAll("[data-panel]")];
let setInfo = null, setPending = 0, setNameSeq = 0, setNameTimer = 0, setNameOk = false;
const fmtDay = ms => new Date(ms).toLocaleDateString(undefined, { day: "numeric", month: "long", year: "numeric" });
const daysUntil = ms => Math.max(1, Math.ceil((ms - Date.now()) / 86400000));
function setMsg(text, kind) { const m = $("setNameMsg"); m.textContent = text || ""; m.className = "set-msg" + (kind ? " " + kind : ""); }
function showSetTab(t) {
  setTabs.forEach(b => b.setAttribute("aria-selected", String(b.dataset.tab === t)));
  setPanels.forEach(p => p.classList.toggle("hidden", p.dataset.panel !== t));
  if (t === "workspaces") { refreshMyStats(); loadMyRooms(); }
  if (t === "appearance") paintTheme();
}
setTabs.forEach(b => b.addEventListener("click", () => showSetTab(b.dataset.tab)));
function paintTheme() {
  const cur = window.SyncTheme ? window.SyncTheme.get() : "system";
  settingsDlg.querySelectorAll(".theme-opt").forEach(b => b.setAttribute("aria-checked", String(b.dataset.mode === cur)));
}
settingsDlg.querySelectorAll(".theme-opt").forEach(b => b.addEventListener("click", () => { if (window.SyncTheme) window.SyncTheme.set(b.dataset.mode); paintTheme(); }));
function renderAccount() {
  if (!curUser) return;
  $("setAvatar").textContent = (curUser.name || "?").trim().charAt(0).toUpperCase() || "?";
  $("setNameShown").textContent = curUser.name;
  const role = roleOf(curUser);
  $("setIdProv").textContent = "#" + curUser.id + " · " + (curUser.dev ? "developer" : role ? role : "member") + " · " + (curUser.provider ? "signed in with " + ((loginProviders.find(p => p.id === curUser.provider) || {}).label || curUser.provider) : "guest on this browser");
  const nc = setInfo && setInfo.nameChange, input = $("setNameInput");
  if (document.activeElement !== input) input.value = curUser.name;
  const locked = !nc || nc.unavailable || !nc.canChange;
  input.disabled = locked; setNameOk = false; $("setNameBtn").disabled = true; clearTimeout(setPending); setLabel($("setNameBtn"), "Change name");
  if (!nc || nc.unavailable) setMsg("Name changes aren't available right now.", "bad");
  else if (!nc.canChange) setMsg("You can change your name again on " + fmtDay(nc.nextAt) + " (in " + daysUntil(nc.nextAt) + (daysUntil(nc.nextAt) === 1 ? " day" : " days") + ").", "");
  else setMsg(nc.lastAt ? "Your last change was on " + fmtDay(nc.lastAt) + ". You can change it now." : "Your first change is free. After it, your name is locked for 30 days.", "");
  updateAuthUi();
}
function setLabel(btn, text) { const l = btn.querySelector(".label"); if (l) l.textContent = text; }
function renderLimits() {
  const L = setInfo && setInfo.limits, ul = $("setLimits"); ul.textContent = "";
  if (!L) { ul.textContent = "Could not load the limits."; return; }
  const n = x => Number(x).toLocaleString();
  [["Name length", "up to " + L.nameMax + " characters, unique (upper/lower case is ignored)"],
   ["Changing your name", "once every " + L.nameDays + " days, starting with a free first change"],
   ["Code in one workspace", "up to " + n(L.maxCode) + " characters"],
   ["People in one workspace", "up to " + L.maxPeople + " at the same time"],
   ["Saved workspaces list", "your latest " + L.savedShown],
   ["Running code", "JavaScript, TypeScript and Lua stop after " + L.runFastSeconds + " s; Python and SQL after " + L.runSlowSeconds + " s"],
   ["Console", "output is cut after " + n(L.outputChars) + " characters; up to " + L.inputLines + " input lines per run"]
  ].forEach(([k, v]) => { const li = document.createElement("li"); const b = document.createElement("b"); b.textContent = k; const s = document.createElement("span"); s.textContent = v; li.append(b, s); ul.append(li); });
}
async function loadSettings() {
  try { const r = await fetch("/api/me/settings", { cache: "no-store" }); if (!r.ok) throw new Error(); setInfo = await r.json(); if (setInfo.user && curUser) curUser.provider = setInfo.user.provider; }
  catch { setInfo = null; }
  renderAccount(); renderLimits();
}
function openSettings() {
  if (!curUser) { askWho(); return; }
  if (settingsDlg.open) return;
  setInfo = null; renderAccount(); renderLimits(); showSetTab("account");
  settingsDlg.showModal(); loadSettings();
}
function closeSettings() { if (!settingsDlg.open) return; settingsDlg.classList.add("closing"); setTimeout(() => { settingsDlg.close(); settingsDlg.classList.remove("closing"); }, 220); }
$("setClose").addEventListener("click", closeSettings);
settingsDlg.addEventListener("click", e => { if (e.target === settingsDlg) closeSettings(); });          // click outside the card
const gear = $("settingsBtn");
gear.addEventListener("click", () => {                       // the wheel turns one full circle, then the pop-up opens
  if (reduceMotion) { openSettings(); return; }
  gear.classList.remove("spin"); void gear.offsetWidth; gear.classList.add("spin");
  setTimeout(openSettings, 260);
});
gear.addEventListener("animationend", () => gear.classList.remove("spin"));

/* change your name */
$("setNameInput").addEventListener("input", () => {
  const v = $("setNameInput").value.trim(), btn = $("setNameBtn"), seq = ++setNameSeq;
  clearTimeout(setNameTimer); clearTimeout(setPending); setLabel(btn, "Change name"); setNameOk = false; btn.disabled = true;
  const nc = setInfo && setInfo.nameChange; if (!nc || !nc.canChange) return;
  if (!v || v === curUser.name) { setMsg(nc.lastAt ? "Your last change was on " + fmtDay(nc.lastAt) + ". You can change it now." : "Your first change is free. After it, your name is locked for 30 days.", ""); return; }
  if (v.toLowerCase() === curUser.name.toLowerCase()) { setNameOk = true; btn.disabled = false; setMsg("Only the capital letters change.", "ok"); return; }
  setMsg("Checking…", "");
  setNameTimer = setTimeout(async () => {
    try {
      const r = await fetch("/api/name-available?name=" + encodeURIComponent(v)), d = await r.json(); if (seq !== setNameSeq) return;
      if (!d.valid) { setMsg("Please enter a valid name.", "bad"); return; }
      setNameOk = Boolean(d.available); btn.disabled = !setNameOk;
      setMsg(d.available ? "✓ \"" + v + "\" is available. Changing it locks your name for 30 days." : "That name is already taken. Please choose another.", d.available ? "ok" : "bad");
    } catch { if (seq === setNameSeq) { setNameOk = true; btn.disabled = false; setMsg("", ""); } }
  }, 300);
});
$("setNameBtn").addEventListener("click", async () => {
  const btn = $("setNameBtn"), v = $("setNameInput").value.trim();
  if (!setNameOk || !v) return;
  if (!setPending) {                                          // first click asks to confirm, because the change locks the name for 30 days
    setLabel(btn, "Confirm change"); setMsg("Click again to confirm. You won't be able to change it again for 30 days.", "bad");
    setPending = setTimeout(() => { setPending = 0; setLabel(btn, "Change name"); setMsg("", ""); }, 6000); return;
  }
  clearTimeout(setPending); setPending = 0; btn.disabled = true; setLabel(btn, "Saving…");
  try {
    const r = await fetch("/api/me/name", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ name: v }) });
    const d = await r.json().catch(() => ({}));
    if (!r.ok) { if (r.status === 429 && d.nextAt) { setInfo = { ...(setInfo || {}), nameChange: { canChange: false, nextAt: d.nextAt } }; renderAccount(); return; } throw new Error(d.error || "Could not change your name."); }
    showUser({ ...curUser, name: d.user.name });
    setInfo = { ...(setInfo || {}), nameChange: { canChange: false, lastAt: Date.now(), nextAt: d.nextAt } };
    renderAccount(); setMsg("Done! You are now " + d.user.name + ". You can change it again on " + fmtDay(d.nextAt) + ".", "ok");
  } catch (e) { setLabel(btn, "Change name"); btn.disabled = false; setMsg(e.message, "bad"); }
});
$("setNameInput").addEventListener("keydown", e => { if (e.key === "Enter") { e.preventDefault(); $("setNameBtn").click(); } });
/* ---------- workspace chat (small popup; messages live in server memory only) ---------- */
let chatMe = null, chatOpen = false, chatUnread = 0, chatRoom = null;
const chatLog = $("chatLog"), chatIn = $("chatIn");
function chatEmptyHint() {
  if (chatLog.querySelector(".cm")) { chatLog.querySelector(".chat-empty")?.remove(); return; }
  if (!chatLog.querySelector(".chat-empty")) { const d = document.createElement("div"); d.className = "chat-empty"; d.textContent = "No messages yet. Say hi to your team."; chatLog.append(d); }
}
function chatTime(ts) { const d = new Date(ts); return d.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }); }
function chatAdd(m, quiet) {
  if (!m || typeof m.text !== "string") return;
  chatLog.querySelector(".chat-empty")?.remove();
  const near = chatLog.scrollHeight - chatLog.scrollTop - chatLog.clientHeight < 80;
  const mine = chatMe && m.aid === chatMe;
  const row = document.createElement("div"); row.className = "cm" + (mine ? " me" : "");
  if (!mine) { const n = document.createElement("span"); n.className = "cm-name"; n.textContent = String(m.name || "Someone"); if (/^#[0-9a-f]{3,8}$/i.test(m.color || "")) n.style.color = m.color; row.append(n); }
  const t = document.createElement("div"); t.className = "cm-text"; t.textContent = m.text;          // textContent only: never HTML
  const tm = document.createElement("span"); tm.className = "cm-time"; tm.textContent = chatTime(m.ts);
  row.append(t, tm); chatLog.append(row);
  while (chatLog.querySelectorAll(".cm").length > 100) chatLog.querySelector(".cm").remove();
  if (near || mine) chatLog.scrollTop = chatLog.scrollHeight;
  if (!quiet && !mine && !chatOpen) { chatUnread++; chatBadge(); }
}
function chatBadge() { const b = $("chatBadge"); b.textContent = chatUnread > 99 ? "99+" : chatUnread; b.classList.toggle("hidden", !chatUnread); }
function chatSetOpen(on) {
  chatOpen = on; $("chatPop").classList.toggle("hidden", !on); $("chatFab").setAttribute("aria-expanded", on ? "true" : "false");
  if (on) { chatUnread = 0; chatBadge(); chatLog.scrollTop = chatLog.scrollHeight; setTimeout(() => chatIn.focus(), 30); }
}
function chatReset() { chatMe = null; chatRoom = null; chatLog.textContent = ""; chatUnread = 0; chatBadge(); chatSetOpen(false); $("chatFab").classList.add("hidden"); }
function chatOnRoom(state) {
  if (chatRoom && chatRoom !== state.id) { chatLog.textContent = ""; chatUnread = 0; chatBadge(); }   // moved to a different workspace: its chat is separate
  chatRoom = state.id; chatMe = state.you && state.you.aid;
  $("chatFab").classList.remove("hidden");
}
socket.on("chat-history", d => {
  if (!d || d.id !== roomId) return;
  chatLog.textContent = ""; (d.messages || []).forEach(m => chatAdd(m, true)); chatEmptyHint();
  chatLog.scrollTop = chatLog.scrollHeight;
});
socket.on("chat-msg", m => chatAdd(m, false));
socket.on("room-deleted", () => chatReset());
$("chatFab").addEventListener("click", () => chatSetOpen(!chatOpen));
$("chatClose").addEventListener("click", () => { chatSetOpen(false); $("chatFab").focus(); });
document.addEventListener("keydown", e => { if (e.key === "Escape" && chatOpen) { chatSetOpen(false); $("chatFab").focus(); } });
$("chatForm").addEventListener("submit", e => {
  e.preventDefault();
  const text = chatIn.value.replace(/\s+/g, " ").trim();
  if (!text || !roomId || !socket.connected) return;
  socket.emit("chat", { id: roomId, text: text.slice(0, 500) });
  chatIn.value = "";
});

/* ---------- notifications (from the developer), the notification section, messages to the developer, "Updates are coming" ---------- */
const notifDlg = $("notifDlg"), notifList = $("notifList"), NOTIF_SEEN_KEY = "syncpit.notifSeen";
let notifs = [], notifPopId = null, notifUserId = undefined, updatesState = { on: false, note: "", by: "" }, inboxUnread = 0;
const getSeen = () => { try { return Number(localStorage.getItem(NOTIF_SEEN_KEY)) || 0; } catch { return 0; } };
const setSeen = ts => { try { if (ts > getSeen()) localStorage.setItem(NOTIF_SEEN_KEY, String(ts)); } catch {} };
const newestTs = () => notifs.reduce((m, n) => Math.max(m, n.ts), 0);
function paintNotifBadge() { const n = notifs.filter(x => x.ts > getSeen()).length, b = $("notifBadge"); b.textContent = n > 9 ? "9+" : String(n); b.classList.toggle("hidden", !n); }
function fmtWhen(ts) {
  const diff = Date.now() - ts; if (diff < 60e3) return "just now"; if (diff < 3600e3) return Math.floor(diff / 60e3) + " min ago"; if (diff < 86400e3) return Math.floor(diff / 3600e3) + " h ago";
  const d = new Date(ts); return d.toLocaleDateString(undefined, { day: "numeric", month: "short" }) + ", " + d.toLocaleTimeString(undefined, { hour: "2-digit", minute: "2-digit" });
}
const fromEl = n => { const w = mk("span", "nf"); w.append(mk("b", n.from.dev ? "rainbow" : "", n.from.name)); if (n.from.dev) w.append(mk("span", "ptag dev-tag", "developer")); return w; };
function renderNotifs() {
  notifList.textContent = "";
  if (!notifs.length) { notifList.append(mk("li", "dc-empty", "No notifications yet.")); return; }
  const seen = getSeen();
  for (const n of notifs) {
    const li = mk("li", "notif" + (n.ts > seen ? " new" : "")), head = mk("div", "notif-head");
    head.append(fromEl(n), mk("small", "", (n.to == null ? "to everyone" : "to you") + " · " + fmtWhen(n.ts)));
    li.append(head, mk("p", "notif-text", n.text)); notifList.append(li);
  }
}
function hideNotifPop() { $("notifPop").classList.add("hidden"); notifPopId = null; setSeen(newestTs()); paintNotifBadge(); }
function showNotifPop(n) {                                           // the latest notification and who it is from, shown as soon as you arrive
  notifPopId = n.id; const f = $("npFrom"); f.textContent = ""; f.append("From ", fromEl(n)); $("npText").textContent = n.text;
  $("notifPop").classList.remove("hidden");
}
async function loadNotifs() {
  try {
    const r = await fetch("/api/notifications", { cache: "no-store" }); if (!r.ok) return;
    notifs = (await r.json()).notifications || []; paintNotifBadge();
    if (notifs[0] && notifs[0].ts > getSeen()) showNotifPop(notifs[0]);
  } catch {}
}
socket.on("notification", n => {
  if (!n || !n.id || notifs.some(x => x.id === n.id)) return;
  notifs.unshift(n); notifs.sort((a, b) => b.ts - a.ts); paintNotifBadge(); showNotifPop(n);
  if (notifDlg.open) { renderNotifs(); setSeen(newestTs()); }
});
socket.on("notification-removed", d => { notifs = notifs.filter(n => n.id !== (d && d.id)); paintNotifBadge(); renderNotifs(); if (notifPopId === (d && d.id)) hideNotifPop(); });
$("notifBtn").addEventListener("click", () => { renderNotifs(); $("notifPop").classList.add("hidden"); setSeen(newestTs()); paintNotifBadge(); paintMsgBox(); notifDlg.showModal(); });
$("notifClose").addEventListener("click", () => notifDlg.close());
$("npOk").addEventListener("click", hideNotifPop); $("npClose").addEventListener("click", hideNotifPop);
$("npAll").addEventListener("click", () => { hideNotifPop(); $("notifBtn").click(); });

// messages to the developer
function msgNote(text, kind) { const e = $("msgNote"); e.textContent = text || ""; e.className = "fb-msg" + (kind ? " " + kind : ""); }
function paintMsgBox() {
  const st = featureStateOf("messages"), box = $("msgBox"), dev = Boolean(curUser && curUser.dev);
  box.classList.toggle("hidden", dev || st === "removed");
  const locked = st === "off" || st === "soon" || !curUser; $("msgText").disabled = locked; $("msgSend").disabled = locked;
  if (!dev) msgNote(st === "soon" ? "Messaging the developer is coming soon." : st === "off" ? "Messaging the developer is turned off right now." : !curUser ? "Pick a name first to write to the developer." : "", st === "on" && curUser ? "" : "bad");
}
$("msgText").addEventListener("input", () => { $("msgCount").textContent = $("msgText").value.length + " / 500"; });
$("msgSend").addEventListener("click", async () => {
  const text = $("msgText").value.trim(); if (text.length < 2) { msgNote("Write your message first.", "bad"); return; }
  $("msgSend").disabled = true; msgNote("Sending…");
  try {
    const r = await fetch("/api/messages", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ text }) });
    const d = await r.json().catch(() => ({})); if (!r.ok) throw new Error(d.error || "Could not send your message.");
    $("msgText").value = ""; $("msgCount").textContent = "0 / 500"; msgNote("Sent. If the developer replies, you will get a notification here.", "ok");
  } catch (e) { msgNote(e.message, "bad"); }
  $("msgSend").disabled = false;
});

// "Updates are coming": the real page stays behind a light blur with the developer's note; nobody but developers can use it
function applyUpdates() {
  const veil = $("updatesVeil"), show = Boolean(updatesState.on) && !(curUser && curUser.dev);
  $("updVeilNote").textContent = updatesState.note || "We are making SyncPit better.";
  veil.classList.toggle("hidden", !show); document.body.classList.toggle("updates-on", show);
  for (const el of document.body.children) if (el !== veil && el.id !== "notifPop" && el.tagName !== "SCRIPT") el.inert = show;
  if (rolesDlg.open && !$("updCard").classList.contains("hidden")) renderUpdatesCard();
}
socket.on("updates", d => { if (d) { updatesState = d; applyUpdates(); } });
function renderUpdatesCard() {
  const card = $("updCard"), dev = isDevUser(); card.classList.toggle("hidden", !dev); if (!dev) return;
  const on = Boolean(updatesState.on), t = $("updToggle");
  const st = $("updState"); st.textContent = on ? "ON for visitors" : "off"; st.className = "ptag" + (on ? " ban-tag" : "");
  t.textContent = on ? "Turn off" : "Turn on"; t.classList.toggle("primary", !on); $("updSave").classList.toggle("hidden", !on);
  if (document.activeElement !== $("updNoteIn") && !$("updNoteIn").value) $("updNoteIn").value = updatesState.note || "";
}
async function setUpdates(on) {
  try { const d = await devPost("/api/dev/updates", { on, note: $("updNoteIn").value }); updatesState = d.updates; applyUpdates(); renderUpdatesCard(); savedNote(d, on ? "Updates are coming is ON. Visitors see the blurred page with your note." : "Updates are coming is off. Everyone can use the site again."); }
  catch (e) { rolesNote(e.message, "bad"); }
}
$("updToggle").addEventListener("click", () => setUpdates(!updatesState.on));
$("updSave").addEventListener("click", () => setUpdates(true));

// developer: send to everyone, and see what was sent
$("notifText").addEventListener("input", () => { $("notifCount").textContent = $("notifText").value.length + " / 500"; });
$("notifAll").addEventListener("click", async () => {
  const text = $("notifText").value.trim(); if (!text) { rolesNote("Write the notification first.", "bad"); return; }
  $("notifAll").disabled = true;
  try { const d = await devPost("/api/dev/notify", { userNumber: null, text }); $("notifText").value = ""; $("notifCount").textContent = "0 / 500"; rolesNote("Sent to everyone (" + d.delivered + " online right now). The rest will see it when they arrive.", "ok"); renderNotifySent(); } catch (e) { rolesNote(e.message, "bad"); }
  $("notifAll").disabled = false;
});
async function renderNotifySent() {
  const ul = $("notifSent"); ul.textContent = ""; ul.append(mk("li", "dc-empty", "Loading…"));
  try {
    const r = await fetch("/api/dev/notify/list", { cache: "no-store" }); if (!r.ok) throw new Error("Could not load the list."); const d = await r.json(); ul.textContent = "";
    if (!d.notifications.length) { ul.append(mk("li", "dc-empty", "Nothing sent yet.")); return; }
    for (const n of d.notifications) {
      const li = mk("li", "dcard"), top = mk("div", "dc-top"), del = mk("button", "danger-btn", "Delete"); del.type = "button";
      top.append(mk("span", "rname", n.to == null ? "To everyone" : "To " + (n.toName || "#" + n.to)), mk("small", "dc-stats", fmtWhen(n.ts)), del); li.append(top, mk("p", "notif-text", n.text));
      armedDelete(del, "Delete", async () => { await devPost("/api/dev/notify/delete", { id: n.id }); li.remove(); rolesNote("Deleted. It is gone for everyone.", "ok"); });
      ul.append(li);
    }
  } catch (e) { ul.textContent = ""; rolesNote(e.message, "bad"); }
}

// developer: "Your inbox"
function paintInboxBadge() { for (const id of ["inboxCount", "inboxDot"]) { const b = $(id); b.textContent = inboxUnread > 9 ? "9+" : String(inboxUnread); b.classList.toggle("hidden", !inboxUnread); } }
async function loadInboxCount() { if (!(curUser && curUser.dev)) return; try { const r = await fetch("/api/dev/inbox", { cache: "no-store" }); if (r.ok) { inboxUnread = (await r.json()).unread || 0; paintInboxBadge(); } } catch {} }
socket.on("inbox-new", d => {
  if (!(curUser && curUser.dev) || !d) return; inboxUnread = d.unread || inboxUnread + 1; paintInboxBadge();
  showNotice("New message from " + (d.message && d.message.from ? d.message.from.name : "someone") + " in Your inbox.", "good");
  if (rolesDlg.open && !$("inboxList").closest("section").classList.contains("hidden")) renderInbox();
});
async function renderInbox() {
  const ul = $("inboxList"); ul.textContent = ""; ul.append(mk("li", "dc-empty", "Loading…"));
  try {
    const r = await fetch("/api/dev/inbox", { cache: "no-store" }); if (!r.ok) throw new Error("Could not load your inbox."); const d = await r.json(); ul.textContent = "";
    inboxUnread = d.unread || 0; paintInboxBadge(); $("inboxInfo").textContent = d.messages.length ? d.unread + " unread of " + d.messages.length : "";
    if (!d.messages.length) { ul.append(mk("li", "dc-empty", "No messages yet.")); return; }
    for (const m of d.messages) {
      const li = mk("li", "dcard inbox-msg" + (m.read ? "" : " unread")), top = mk("div", "dc-top");
      const nm = mk("span", "rname", m.from.name); nm.append(mk("small", "", "#" + m.from.id + " · " + fmtWhen(m.ts))); top.append(nm);
      const rd = mk("button", "", m.read ? "Mark unread" : "Mark read"); rd.type = "button"; const del = mk("button", "danger-btn", "Delete"); del.type = "button"; top.append(rd, del);
      rd.addEventListener("click", async () => { rd.disabled = true; try { await devPost("/api/dev/inbox/read", { id: m.id, read: !m.read }); renderInbox(); } catch (e) { rolesNote(e.message, "bad"); rd.disabled = false; } });
      armedDelete(del, "Delete", async () => { await devPost("/api/dev/inbox/delete", { id: m.id }); renderInbox(); });
      const rp = mk("div", "dc-row"), ri = document.createElement("input"); ri.maxLength = 500; ri.placeholder = "Reply to " + m.from.name + " (they get a notification)"; ri.setAttribute("aria-label", "Reply to " + m.from.name);
      const rb = mk("button", "primary", "Reply"); rb.type = "button"; rp.append(ri, rb);
      rb.addEventListener("click", async () => { if (!ri.value.trim()) return; rb.disabled = true; try { await devPost("/api/dev/notify", { userNumber: m.from.id, text: ri.value }); if (!m.read) await devPost("/api/dev/inbox/read", { id: m.id }); ri.value = ""; rolesNote("Reply sent to " + m.from.name + ".", "ok"); renderInbox(); } catch (e) { rolesNote(e.message, "bad"); rb.disabled = false; } });
      ri.addEventListener("keydown", e => { if (e.key === "Enter") rb.click(); });
      li.append(top, mk("p", "notif-text", m.text), rp); ul.append(li);
    }
  } catch (e) { ul.textContent = ""; rolesNote(e.message, "bad"); }
}
$("inboxReadAll").addEventListener("click", async () => { try { await devPost("/api/dev/inbox/read", { all: true }); renderInbox(); } catch (e) { rolesNote(e.message, "bad"); } });
function onUserShown(u) {                                            // runs every time who you are is (re)drawn
  if (notifUserId !== u.id) { notifUserId = u.id; loadNotifs(); loadInboxCount(); }
  applyUpdates(); paintMsgBox();
}
chatEmptyHint();
renderPeers([]);
if (!joinFromPath()) setStatus("Not connected", false);
})();
