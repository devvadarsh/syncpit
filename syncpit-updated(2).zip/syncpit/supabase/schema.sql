-- Run this once in Supabase: SQL Editor -> New query -> paste -> Run

create table if not exists public.rooms (
  id               text primary key,
  code             text        not null default '',
  language         text        not null default 'Plain text',
  owner_token_hash text        not null,
  locked           boolean     not null default false,
  created_at       timestamptz not null default now(),
  updated_at       timestamptz not null default now()
);

-- Lock the table down. The server uses the service_role key (which bypasses RLS);
-- with RLS on and no policies, nobody using the public anon key can read or change rooms.
alter table public.rooms enable row level security;

-- People who use SyncPit (no login): one row per browser session. Only a hash of the session token is stored.
create table if not exists public.users (
  id         bigint generated always as identity primary key,
  token_hash text not null unique,
  name       text not null,
  created_at timestamptz not null default now()
);
alter table public.users enable row level security;

-- Usernames are unique, ignoring upper/lower case ("Aarav" and "aarav" are the same name).
-- If this fails, you already have two users with the same name: rename or delete one first.
create unique index if not exists users_name_lower_key on public.users (lower(name));

-- Ranks (tags only): the developer creates and deletes ranks on the website. A user's rank is just its name in this column.
-- The old fixed list (admin / moderator) is gone, so the check that enforced it is dropped.
alter table public.users add column if not exists role text null;
alter table public.users drop constraint if exists users_role_check;
-- Nobody keeps the retired built-in ranks. This runs only the first time (before site_state exists), so ranks you create later are never touched.
do $$
begin
  if to_regclass('public.site_state') is null then
    update public.users set role = null where role in ('admin', 'moderator');
  end if;
end $$;

-- Developer settings: ranks (names + colors), bans, and switched-off features, kept as small JSON documents.
create table if not exists public.site_state (
  key        text primary key,
  value      jsonb not null,
  updated_at timestamptz not null default now()
);
alter table public.site_state enable row level security;

-- Workspace counts: who created which workspace, and how many each person has created in total (the total survives deleting a workspace).
-- Workspaces made before this was added have no creator and are not counted.
alter table public.rooms add column if not exists creator_id bigint null;
create index if not exists rooms_creator_idx on public.rooms (creator_id);
alter table public.users add column if not exists rooms_created integer not null default 0;

-- Sign in with Google / GitHub / ... (Supabase Auth). Only a private sign-in id and the provider name are kept: no email, no password, no photo.
alter table public.users add column if not exists auth_id uuid null;
alter table public.users add column if not exists auth_provider text null;
create unique index if not exists users_auth_id_key on public.users (auth_id) where auth_id is not null;
-- One account can be signed in on several browsers and devices at once.
create table if not exists public.user_sessions (
  token_hash text primary key,
  user_id    bigint not null references public.users(id) on delete cascade,
  created_at timestamptz not null default now()
);
alter table public.user_sessions enable row level security;

-- Name changes: the time of the last change (a name can be changed once every 30 days).
alter table public.users add column if not exists name_changed_at timestamptz null;

-- Makes the API notice new tables and columns right away.
notify pgrst, 'reload schema';
