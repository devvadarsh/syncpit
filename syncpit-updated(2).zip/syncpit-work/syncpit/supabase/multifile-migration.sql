-- Run once in Supabase SQL Editor to enable multi-file workspaces.
alter table public.rooms add column if not exists files jsonb not null default '{}'::jsonb;
alter table public.rooms add column if not exists active_file text not null default 'main.txt';
notify pgrst, 'reload schema';
