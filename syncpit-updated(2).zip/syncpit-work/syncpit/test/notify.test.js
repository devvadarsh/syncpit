// Developer id, feature states (on/off/soon/removed), notifications, "Updates are coming" and messages to the developer. Run: node test/notify.test.js
process.env.DEV_MEMORY = "1"; process.env.DEV_MEMORY_DB = "1";
delete process.env.DEVELOPER_USER_ID;                       // the real default: the developer is user #5 only
const assert = require("assert");
const WebSocket = require("ws");
const { server } = require("../server.js");

function sioClient(port, cookie) {
  const ws = new WebSocket(`ws://127.0.0.1:${port}/socket.io/?EIO=4&transport=websocket`, { headers: cookie ? { cookie } : {} });
  const handlers = {}, log = []; let ok, bad; const ready = new Promise((a, b) => { ok = a; bad = b; });
  const api = {
    log, ready, emit(ev, payload) { ws.send("42" + JSON.stringify([ev, payload])); },
    next(ev, ms = 3000) { return new Promise((res, rej) => { const t = setTimeout(() => rej(new Error("timeout waiting for " + ev)), ms); (handlers[ev] = handlers[ev] || []).push(function once(d) { clearTimeout(t); handlers[ev] = handlers[ev].filter(x => x !== once); res(d); }); }); },
    count(ev) { return log.filter(x => x === ev).length; }, close() { ws.close(); }
  };
  ws.on("message", raw => {
    const m = raw.toString();
    if (m === "2") return ws.send("3"); if (m[0] === "0") return ws.send("40"); if (m.startsWith("40")) return ok(); if (m.startsWith("44")) return bad(new Error("refused: " + m));
    const mm = m.match(/^42(\d*)(\[.*)$/); if (!mm) return; const arr = JSON.parse(mm[2]); log.push(arr[0]); (handlers[arr[0]] || []).slice().forEach(fn => fn(arr[1]));
  });
  ws.on("error", () => bad(new Error("socket error")));
  return api;
}
const sleep = ms => new Promise(r => setTimeout(r, ms));

(async () => {
  await new Promise(r => server.listen(0, r));
  const port = server.address().port, base = `http://127.0.0.1:${port}`, J = { "content-type": "application/json" };
  const newUser = async name => { const r = await fetch(base + "/api/me", { method: "POST", headers: J, body: JSON.stringify({ name }) }); return { body: await r.json(), cookie: (r.headers.get("set-cookie") || "").split(";")[0] }; };
  const call = (cookie, url, body, extra = {}) => fetch(base + url, { method: "POST", headers: { ...J, ...(cookie ? { cookie } : {}), ...extra }, body: JSON.stringify(body) });
  const get = (cookie, url) => fetch(base + url, { headers: cookie ? { cookie } : {} });
  const sock = async user => { const c = sioClient(port, user.cookie); await c.ready; return c; };

  // accounts #1..#4 are ordinary people, #5 is the developer, #6 is ordinary too
  const u1 = await newUser("Ann"), u2 = await newUser("Bob"), u3 = await newUser("Cat"), u4 = await newUser("Dan"), dev = await newUser("Boss"), u6 = await newUser("Eve");
  assert.strictEqual(dev.body.user.id, 5); assert.strictEqual(dev.body.user.dev, true, "#5 is the developer");
  for (const u of [u1, u2, u3, u4, u6]) assert.strictEqual(u.body.user.dev, false, "#" + u.body.user.id + " is not a developer");
  assert.strictEqual((await call(u6.cookie, "/api/dev/ranks", { name: "X", color: "#ff0000" })).status, 404, "#6 can't use developer routes");
  assert.strictEqual((await call(u1.cookie, "/api/dev/notify", { text: "hi" })).status, 404);
  console.log("ok  developer: only #5 is the developer (not #1 or #6)");

  // feature states
  const st = async () => (await (await get(null, "/api/ranks")).json());
  for (const state of ["off", "soon", "removed"]) {
    assert.strictEqual((await call(dev.cookie, "/api/dev/features", { feature: "create", state })).status, 200);
    assert.strictEqual((await st()).featureStates.create, state); assert.deepStrictEqual((await st()).globalOff, ["create"]);
    const r = await call(u1.cookie, "/api/rooms", { code: "x" }); assert.strictEqual(r.status, 403, "create is blocked when " + state);
    assert.strictEqual((await call(dev.cookie, "/api/rooms", { code: "x" })).status, 200, "developer is never limited (" + state + ")");
  }
  assert.strictEqual((await call(dev.cookie, "/api/dev/features", { feature: "create", state: "on" })).status, 200, "revive");
  assert.deepStrictEqual((await st()).featureStates, {}); assert.strictEqual((await call(u1.cookie, "/api/rooms", { code: "x" })).status, 200, "back on");
  assert.strictEqual((await call(dev.cookie, "/api/dev/features", { feature: "create", state: "gone" })).status, 400);
  assert.strictEqual((await call(dev.cookie, "/api/dev/features", { feature: "nope", state: "soon" })).status, 400);
  assert.strictEqual((await call(u1.cookie, "/api/dev/features", { feature: "create", state: "removed" })).status, 404);
  assert.ok(Object.keys((await st()).features).includes("messages"));
  console.log("ok  features: on / off / soon / removed for everyone except developers, and any of them can be revived");

  // notifications: everyone, then one person; sender shown; live push; stored for later
  const live1 = await sock(u1), live2 = await sock(u2), liveDev = await sock(dev);
  const got1 = live1.next("notification"), got2 = live2.next("notification");
  const sent = await call(dev.cookie, "/api/dev/notify", { userNumber: null, text: "  Welcome <b>everyone</b>!  " });
  assert.strictEqual(sent.status, 200); const sb = await sent.json(); assert.ok(sb.delivered >= 3);
  const n1 = await got1; await got2;
  assert.strictEqual(n1.text, "Welcome beveryone/b!", "< and > are stripped"); assert.deepStrictEqual([n1.from.name, n1.from.dev, n1.to], ["Boss", true, null], "shows who sent it");
  const quiet = live2.count("notification");
  const only1 = live1.next("notification");
  assert.strictEqual((await call(dev.cookie, "/api/dev/notify", { userNumber: u1.body.user.id, text: "Just for Ann" })).status, 200);
  assert.strictEqual((await only1).text, "Just for Ann"); await sleep(150); assert.strictEqual(live2.count("notification"), quiet, "the other person did not get it live");
  const list = async u => (await (await get(u && u.cookie, "/api/notifications")).json()).notifications;
  assert.deepStrictEqual((await list(u1)).map(n => n.text), ["Just for Ann", "Welcome beveryone/b!"], "newest first, both visible to Ann");
  assert.deepStrictEqual((await list(u2)).map(n => n.text), ["Welcome beveryone/b!"], "Bob never sees Ann's private one");
  assert.deepStrictEqual((await list(null)).map(n => n.text), ["Welcome beveryone/b!"], "visitors see the public ones");
  for (const bad of [{ text: "" }, { text: "   " }, { userNumber: 999, text: "x" }, { userNumber: "2", text: "x" }]) assert.ok([400, 404].includes((await call(dev.cookie, "/api/dev/notify", bad)).status), "rejects " + JSON.stringify(bad));
  assert.strictEqual((await call(dev.cookie, "/api/dev/notify", { text: "x" }, { origin: "http://evil.example" })).status, 403, "cross-site refused");
  const recent = await (await get(dev.cookie, "/api/dev/notify/list")).json(); assert.strictEqual(recent.notifications[0].toName, "Ann");
  const gone = live2.next("notification-removed"); assert.strictEqual((await call(dev.cookie, "/api/dev/notify/delete", { id: recent.notifications[1].id })).status, 200); await gone;
  assert.deepStrictEqual((await list(u2)).map(n => n.text), [], "deleted for everyone");
  console.log("ok  notifications: to everyone or one person with one call, live and saved, sender shown, private ones stay private");

  // a rank with the power can notify too, but only the developer can use the inbox and the updates mode
  assert.strictEqual((await call(dev.cookie, "/api/dev/ranks", { name: "Crier", color: "#00ff00", powers: ["notify_users"] })).status, 200);
  assert.strictEqual((await call(dev.cookie, "/api/roles", { userNumber: u3.body.user.id, role: "Crier" })).status, 200);
  assert.strictEqual((await call(u3.cookie, "/api/dev/notify", { userNumber: u2.body.user.id, text: "from a crier" })).status, 200);
  assert.strictEqual((await call(u1.cookie, "/api/dev/notify", { text: "nope" })).status, 404);
  assert.strictEqual((await get(u3.cookie, "/api/dev/inbox")).status, 404); assert.strictEqual((await call(u3.cookie, "/api/dev/updates", { on: true })).status, 404);
  console.log("ok  notifications: the Send notifications power works; inbox and Updates mode stay developer-only");

  // messages to the developer, "Your inbox"
  const inboxLive = liveDev.next("inbox-new");
  assert.strictEqual((await call(null, "/api/messages", { text: "hello dev" })).status, 401, "must have a name");
  assert.strictEqual((await call(u1.cookie, "/api/messages", { text: "x" })).status, 400);
  assert.strictEqual((await call(u1.cookie, "/api/messages", { text: "Hi <i>dev</i>, found a bug" }, { origin: "http://evil.example" })).status, 403);
  assert.strictEqual((await call(u1.cookie, "/api/messages", { text: "Hi <i>dev</i>, found a bug" })).status, 200);
  const live = await inboxLive; assert.strictEqual(live.message.text, "Hi idev/i, found a bug"); assert.strictEqual(live.unread, 1, "the developer is told live");
  assert.strictEqual((await call(dev.cookie, "/api/messages", { text: "me to me" })).status, 400, "the developer doesn't message themselves");
  assert.strictEqual((await get(u1.cookie, "/api/dev/inbox")).status, 404, "nobody else can read the inbox");
  let box = await (await get(dev.cookie, "/api/dev/inbox")).json(); assert.deepStrictEqual([box.messages.length, box.unread, box.messages[0].from.name], [1, 1, "Ann"]);
  assert.strictEqual((await call(dev.cookie, "/api/dev/inbox/read", { id: box.messages[0].id })).status, 200);
  assert.strictEqual((await (await get(dev.cookie, "/api/dev/inbox")).json()).unread, 0);
  assert.strictEqual((await call(dev.cookie, "/api/dev/inbox/read", { id: "nope" })).status, 404);
  const reply = live1.next("notification"); assert.strictEqual((await call(dev.cookie, "/api/dev/notify", { userNumber: box.messages[0].from.id, text: "Thanks, fixed!" })).status, 200); assert.strictEqual((await reply).text, "Thanks, fixed!");
  assert.strictEqual((await call(dev.cookie, "/api/dev/inbox/delete", { id: box.messages[0].id })).status, 200);
  assert.strictEqual((await (await get(dev.cookie, "/api/dev/inbox")).json()).messages.length, 0);
  assert.strictEqual((await call(dev.cookie, "/api/dev/features", { feature: "messages", state: "removed" })).status, 200);
  assert.strictEqual((await call(u2.cookie, "/api/messages", { text: "still there?" })).status, 403, "when the feature is removed nobody can message");
  await call(dev.cookie, "/api/dev/features", { feature: "messages", state: "on" });
  for (let i = 0; i < 12; i++) await call(u4.cookie, "/api/messages", { text: "spam " + i });
  assert.strictEqual((await call(u4.cookie, "/api/messages", { text: "one more" })).status, 429, "the eleventh message in an hour is refused");
  const flood = await (await get(dev.cookie, "/api/dev/inbox")).json(); assert.ok(flood.messages.filter(m => m.from.name === "Dan").length <= 10, "at most 10 messages an hour per person");
  console.log("ok  messages: people write to the developer, who gets them live in Your inbox, can reply, mark read and delete; limits apply");

  // "Updates are coming"
  assert.strictEqual((await st()).updates.on, false);
  const room = await (await call(u1.cookie, "/api/rooms", { code: "start" })).json();
  const inRoom = await sock(u2); const stt = inRoom.next("room-state"); inRoom.emit("join-room", { id: room.id }); await stt;
  const told = inRoom.next("updates");
  assert.strictEqual((await call(dev.cookie, "/api/dev/updates", { on: true, note: "Adding <b>new</b> features. Back in 30 min." })).status, 200);
  const upd = await told; assert.deepStrictEqual([upd.on, upd.note, upd.by], [true, "Adding bnew/b features. Back in 30 min.", "Boss"], "everyone is told live, with the note");
  assert.deepStrictEqual((await st()).updates.on, true, "and anybody opening the page learns it from /api/ranks");
  assert.strictEqual((await get(u2.cookie, "/")).status, 200, "the page still opens (it shows blurred behind the note)");
  assert.strictEqual((await call(u2.cookie, "/api/rooms", { code: "x" })).status, 503, "but nothing can be used");
  assert.strictEqual((await call(u2.cookie, "/api/messages", { text: "can I?" })).status, 503);
  const blocked = inRoom.next("permission-error"); inRoom.emit("chat", { id: room.id, text: "hello" }); assert.ok((await blocked).includes("Updates are coming"));
  assert.strictEqual((await call(dev.cookie, "/api/rooms", { code: "x" })).status, 200, "the developer can use everything");
  assert.strictEqual((await call(null, "/api/dev/updates", { on: false })).status, 503); assert.strictEqual((await call(u2.cookie, "/api/dev/updates", { on: false })).status, 503, "while it is on, everybody but the developer is blocked from every change, this one included");
  assert.strictEqual((await get(null, "/api/dev/inbox")).status, 404, "reads still answer as before");
  assert.strictEqual((await call(dev.cookie, "/api/dev/updates", { on: "yes" })).status, 400);
  const backOn = inRoom.next("updates"); assert.strictEqual((await call(dev.cookie, "/api/dev/updates", { on: false })).status, 200); assert.strictEqual((await backOn).on, false);
  assert.strictEqual((await call(u2.cookie, "/api/rooms", { code: "x" })).status, 200, "turned off: everyone is back");
  assert.strictEqual((await call(u2.cookie, "/api/dev/updates", { on: true })).status, 404, "and the developer routes are plain 404s for others again");
  const chatBack = inRoom.next("chat-msg"); inRoom.emit("chat", { id: room.id, text: "hello again" }); assert.strictEqual((await chatBack).text, "hello again");
  console.log("ok  updates: the page opens but can't be used (HTTP and sockets) for everyone except the developer; note and on/off reach everyone live");

  [live1, live2, liveDev, inRoom].forEach(c => c.close()); server.close(); setTimeout(() => process.exit(0), 100);
})().catch(e => { console.error("FAIL", e); process.exit(1); });
